
import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { UserProfile } from '../types';

declare global {
  interface Window {
    google: any; // Google Identity Services (GIS)
  }
}

interface AuthContextType {
  user: UserProfile | null;
  isAuthLoading: boolean;
  authError: string | null;
  logout: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Simple JWT decoder for client-side use (DOES NOT VERIFY SIGNATURE)
const decodeJwt = (token: string): any => {
  try {
    const base64Url = token.split('.')[1];
    const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
    const jsonPayload = decodeURIComponent(
      atob(base64)
        .split('')
        .map((c) => '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2))
        .join('')
    );
    return JSON.parse(jsonPayload);
  } catch (error) {
    console.error("Error decoding JWT:", error);
    return null;
  }
};


export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<UserProfile | null>(null);
  const [isAuthLoading, setIsAuthLoading] = useState(true);
  const [authError, setAuthError] = useState<string | null>(null);

  const GOOGLE_CLIENT_ID = process.env.GOOGLE_CLIENT_ID;

  useEffect(() => {
    setIsAuthLoading(true);
    if (!GOOGLE_CLIENT_ID) {
      setAuthError("Google Client ID not configured. Sign-In disabled.");
      setIsAuthLoading(false);
      console.warn("Google Client ID (process.env.GOOGLE_CLIENT_ID) is missing.");
      return;
    }

    const script = document.createElement('script');
    script.src = 'https://accounts.google.com/gsi/client';
    script.async = true;
    script.defer = true;
    script.onload = () => {
      if (window.google && window.google.accounts && window.google.accounts.id) {
        window.google.accounts.id.initialize({
          client_id: GOOGLE_CLIENT_ID,
          callback: handleCredentialResponse,
        });
        // Try to render the button after initialization.
        // The actual div might not be in the DOM yet if Header hasn't rendered.
        // We'll rely on Header to call renderButton again if needed.
        renderGoogleButton(); 
        setIsAuthLoading(false);
      } else {
        setAuthError("Failed to load Google Identity Services.");
        setIsAuthLoading(false);
      }
    };
    script.onerror = () => {
        setAuthError("Error loading Google Sign-In script.");
        setIsAuthLoading(false);
    };
    document.body.appendChild(script);

    return () => {
        document.body.removeChild(script);
    };

  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [GOOGLE_CLIENT_ID]);


  const handleCredentialResponse = (response: any) => {
    setIsAuthLoading(true);
    try {
      const idToken = response.credential;
      const decodedToken = decodeJwt(idToken);

      if (decodedToken) {
        const userProfile: UserProfile = {
          id: decodedToken.sub,
          name: decodedToken.name,
          email: decodedToken.email,
          picture: decodedToken.picture,
        };
        setUser(userProfile);
        setAuthError(null);
      } else {
        throw new Error("Failed to decode token.");
      }
    } catch (error) {
      console.error("Error processing Google Sign-In:", error);
      setAuthError("Failed to process Google Sign-In. Please try again.");
      setUser(null);
    } finally {
      setIsAuthLoading(false);
    }
  };
  
  // Expose a function to render the button, to be called by Header
  // if the initial render in useEffect happens too early.
  const renderGoogleButton = () => {
    if (GOOGLE_CLIENT_ID && window.google && window.google.accounts && window.google.accounts.id) {
       const buttonContainer = document.getElementById('googleSignInButtonContainer');
       if (buttonContainer && !buttonContainer.hasChildNodes()) { // Render only if empty
         window.google.accounts.id.renderButton(
           buttonContainer,
           { theme: 'outline', size: 'large', type: 'standard', text: 'signin_with' }
         );
       }
    }
  };

  // Call renderGoogleButton when user state changes (e.g., after logout)
  // or if authError clears, ensuring the button is present if it should be.
  useEffect(() => {
    if (!user && !authError && GOOGLE_CLIENT_ID) {
      renderGoogleButton();
    }
  }, [user, authError, GOOGLE_CLIENT_ID]);


  const logout = () => {
    setUser(null);
    if (window.google && window.google.accounts && window.google.accounts.id) {
      window.google.accounts.id.disableAutoSelect();
      // Prompt for account selection on next sign-in attempt
      window.google.accounts.id.prompt(); 
    }
    // No explicit "sign out" for GIS token model, just clear client state.
  };

  return (
    <AuthContext.Provider value={{ user, isAuthLoading, authError, logout }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
