
import React, { useState, useRef, useMemo, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useOperators } from '../hooks/useOperators';
import { OperatorCard } from '../components/OperatorCard';
import { PlusIcon, ChartBarIcon, UploadIcon, InformationCircleIcon } from '../components/icons';
import { LoadingSpinner } from '../components/shared/LoadingSpinner';
import { Operator, RiskLevel, DEFAULT_COMPLEXITY_FACTORS, DEFAULT_COMPLIANCE_DATA, DEFAULT_DEVIATION_DATA, DEFAULT_IMPROVEMENT_DATA, DEFAULT_LEGACY_RISK_FACTORS, ComplexityFactors, ComplianceData, DeviationData, ImprovementData, LegacyRiskFactors, ComplianceFindingCounts, SurveillanceFinding, FindingCategoryLevel } from '../types';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, Cell } from 'recharts';
import { CHART_HEX_RISK_LEVEL_COLORS } from '../constants';
import Papa from 'papaparse';
import toast from 'react-hot-toast';
import { GoogleGenAI, GenerateContentResponse } from '@google/genai';

// Helper to map Risk Indicator Level (1-5) to a general RiskLevel for color consistency
const mapIndicatorToRiskLevel = (indicatorLevel: number): RiskLevel => {
    if (indicatorLevel === 1) return RiskLevel.LOW;
    if (indicatorLevel === 2) return RiskLevel.MEDIUM;
    if (indicatorLevel === 3) return RiskLevel.MEDIUM;
    if (indicatorLevel === 4) return RiskLevel.HIGH;
    if (indicatorLevel === 5) return RiskLevel.CRITICAL;
    return RiskLevel.LOW;
};

// Helper function to set nested properties using dot notation
const setValueByPath = (obj: any, path: string, value: any) => {
    const keys = path.split('.');
    let current = obj;
    keys.forEach((key, index) => {
        if (index === keys.length - 1) {
            current[key] = value;
        } else {
            if (!current[key] || typeof current[key] !== 'object') {
                current[key] = {};
            }
            current = current[key];
        }
    });
};

const parseBooleanValue = (value: string | undefined): boolean | undefined => {
    if (value === undefined || value === null || value.trim() === '') return undefined;
    const lowerValue = value.toLowerCase();
    if (['true', 'yes', '1', 'ya'].includes(lowerValue)) return true;
    if (['false', 'no', '0', 'tidak'].includes(lowerValue)) return false;
    return undefined; 
};

const parseNumberValue = (value: string | undefined, defaultValue: number = 0): number => {
    if (value === undefined || value === null || value.trim() === '') return defaultValue;
    const num = Number(String(value).replace(/,/g, '')); // Handle thousand separators if any
    return isNaN(num) ? defaultValue : num;
};


export const DashboardPage: React.FC = () => {
  const { operators, addOperator } = useOperators();
  const [searchTerm, setSearchTerm] = useState('');
  const [isImporting, setIsImporting] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // AI Advisory State
  const [aiDashboardClient, setAiDashboardClient] = useState<GoogleGenAI | null>(null);
  const [aiAdvisory, setAiAdvisory] = useState('');
  const [isAiAdvisoryLoading, setIsAiAdvisoryLoading] = useState(false);
  const [aiAdvisoryError, setAiAdvisoryError] = useState<string | null>(null);
  const API_KEY = process.env.API_KEY;

  useEffect(() => {
    if (API_KEY) {
      try {
        const client = new GoogleGenAI({ apiKey: API_KEY });
        setAiDashboardClient(client);
        setAiAdvisoryError(null);
      } catch (error) {
        console.error("Failed to initialize GoogleGenAI client for dashboard:", error);
        setAiAdvisoryError("Failed to initialize AI client. Check API key configuration.");
        setAiDashboardClient(null);
      }
    } else {
      setAiDashboardClient(null);
    }
  }, [API_KEY]);

  const filteredOperators = operators.filter(op => 
    op.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    op.aocNumber.toLowerCase().includes(searchTerm.toLowerCase())
  ).sort((a,b) => {
    if (a.riskIndicatorLevel !== b.riskIndicatorLevel) {
        return b.riskIndicatorLevel - a.riskIndicatorLevel;
    }
    return a.overallPerformanceScore - b.overallPerformanceScore;
  });
  
  const chartData = operators.map(op => ({
    name: op.name.length > 15 ? op.name.substring(0,12) + '...' : op.name,
    performanceScore: op.overallPerformanceScore * 100,
    fill: CHART_HEX_RISK_LEVEL_COLORS[mapIndicatorToRiskLevel(op.riskIndicatorLevel)], 
    riskIndicatorLevel: op.riskIndicatorLevel,
    exposureLevel: op.exposureLevel
  })).sort((a,b) => {
    if (a.riskIndicatorLevel !== b.riskIndicatorLevel) {
        return b.riskIndicatorLevel - a.riskIndicatorLevel;
    }
    return a.performanceScore - b.performanceScore;
  }).slice(0,10);

  const handleImportButtonClick = () => {
    fileInputRef.current?.click();
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setIsImporting(true);
    toast.loading('Importing CSV...', { id: 'csv-import' });

    Papa.parse(file, {
      header: true,
      skipEmptyLines: true,
      complete: (results) => {
        setIsImporting(false);
        toast.dismiss('csv-import');
        let importedCount = 0;
        let skippedCount = 0;

        results.data.forEach((row: any, index: number) => {
          const operatorShell: Pick<Operator, 'name' | 'aocNumber'> & {
            logoUrl?: string;
            complexityFactors?: Partial<ComplexityFactors>;
            complianceData?: Partial<ComplianceData> & { findings?: Partial<ComplianceFindingCounts> };
            deviationData?: Partial<DeviationData>;
            improvementData?: Partial<ImprovementData>;
            legacyRiskFactors?: Partial<LegacyRiskFactors>;
          } = { name: '', aocNumber: '' };
          
          let hasError = false;

          for (const key in row) {
            const value = row[key]?.trim();
            if (key === 'name') operatorShell.name = value;
            else if (key === 'aocNumber') operatorShell.aocNumber = value;
            else if (key === 'logoUrl') operatorShell.logoUrl = value;
            else if (key.startsWith('complexityFactors.')) {
                 if (!operatorShell.complexityFactors) operatorShell.complexityFactors = {};
                 const subKey = key.split('.')[1] as keyof ComplexityFactors;
                 if (subKey === 'hasInternationalOps') {
                    const boolVal = parseBooleanValue(value);
                    if (boolVal !== undefined) setValueByPath(operatorShell, key, boolVal);
                 } else {
                    setValueByPath(operatorShell, key, parseNumberValue(value));
                 }
            } else if (key.startsWith('complianceData.findings.')) {
                 if (!operatorShell.complianceData) operatorShell.complianceData = {};
                 if (!operatorShell.complianceData.findings) {
                    operatorShell.complianceData.findings = { ...DEFAULT_COMPLIANCE_DATA.findings };
                 }
                 setValueByPath(operatorShell, key, parseNumberValue(value));
            } else if (key === 'complianceData.totalChecklistItems') {
                 if (!operatorShell.complianceData) operatorShell.complianceData = {};
                 setValueByPath(operatorShell, key, parseNumberValue(value, DEFAULT_COMPLIANCE_DATA.totalChecklistItems));
            } else if (key.startsWith('deviationData.')) {
                 if (!operatorShell.deviationData) operatorShell.deviationData = {};
                 setValueByPath(operatorShell, key, parseNumberValue(value, key === 'totalFlightCycles' ? DEFAULT_DEVIATION_DATA.totalFlightCycles : 0));
            } else if (key.startsWith('improvementData.')) {
                 if (!operatorShell.improvementData) operatorShell.improvementData = {};
                 setValueByPath(operatorShell, key, parseNumberValue(value));
            } else if (key.startsWith('legacyRiskFactors.')) {
                 if (!operatorShell.legacyRiskFactors) operatorShell.legacyRiskFactors = {};
                 const subKey = key.split('.')[1] as keyof LegacyRiskFactors;
                 if (subKey === 'aircraftFrequency' || subKey === 'environmentalComplexity') {
                    setValueByPath(operatorShell, key, parseNumberValue(value,1));
                 }
            }
          }

          if (!operatorShell.name || !operatorShell.aocNumber) {
            toast.error(`Row ${index + 1}: Skipped. Operator Name and AOC Number are required.`);
            skippedCount++;
            hasError = true;
          }
          
          if (!hasError) {
            try {
              const finalOperatorData = {
                name: operatorShell.name,
                aocNumber: operatorShell.aocNumber,
                logoUrl: operatorShell.logoUrl,
                complexityFactors: { ...DEFAULT_COMPLEXITY_FACTORS, ...operatorShell.complexityFactors },
                complianceData: { 
                    ...DEFAULT_COMPLIANCE_DATA, 
                    ...operatorShell.complianceData,
                    findings: { ...DEFAULT_COMPLIANCE_DATA.findings, ...operatorShell.complianceData?.findings }
                },
                deviationData: { ...DEFAULT_DEVIATION_DATA, ...operatorShell.deviationData },
                improvementData: { ...DEFAULT_IMPROVEMENT_DATA, ...operatorShell.improvementData },
                legacyRiskFactors: { ...DEFAULT_LEGACY_RISK_FACTORS, ...operatorShell.legacyRiskFactors, occurrences: operatorShell.legacyRiskFactors?.occurrences || [] },
              };
              addOperator(finalOperatorData);
              importedCount++;
            } catch (e: any) {
                toast.error(`Row ${index + 1}: Error adding operator "${operatorShell.name || 'Unknown'}". ${e.message}`);
                skippedCount++;
            }
          }
        });

        if (importedCount > 0) {
          toast.success(`${importedCount} operator(s) imported successfully.`);
        }
        if (skippedCount > 0) {
          toast.error(`${skippedCount} row(s) could not be imported. Check CSV format.`);
        } else if (importedCount === 0 && results.data.length > 0) {
          toast.error('No operators were imported. Please check CSV format and content.');
        } else if (results.data.length === 0) {
            toast.success('CSV file is empty or contains no data rows.');
        }
        if (fileInputRef.current) fileInputRef.current.value = '';
      },
      error: (error: Error) => {
        setIsImporting(false);
        toast.dismiss('csv-import');
        toast.error(`CSV Parsing Error: ${error.message}`);
        if (fileInputRef.current) fileInputRef.current.value = '';
      }
    });
  };

  const topSurveillanceFindings = useMemo(() => {
    const oneYearAgo = new Date();
    oneYearAgo.setFullYear(oneYearAgo.getFullYear() - 1);

    const findingCounts: Record<string, number> = {};

    operators.forEach(op => {
      (op.surveillanceFindings || []).forEach(sf => {
        if (new Date(sf.dateAdded) >= oneYearAgo) {
          const findingText = sf.finding.trim().toLowerCase();
          findingCounts[findingText] = (findingCounts[findingText] || 0) + 1;
        }
      });
    });

    return Object.entries(findingCounts)
      .map(([finding, count]) => ({ finding, count }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 5);
  }, [operators]);

  const handleGenerateOverallRecommendations = async () => {
    if (!aiDashboardClient) {
      setAiAdvisoryError("AI client is not initialized.");
      return;
    }
    setIsAiAdvisoryLoading(true);
    setAiAdvisory('');
    setAiAdvisoryError(null);

    // Aggregate data for the prompt
    const idrDistribution = operators.reduce((acc, op) => {
      const level = `IDR ${op.riskIndicatorLevel}`;
      acc[level] = (acc[level] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    const openFindingsByCategory = operators.reduce((acc, op) => {
        (op.surveillanceFindings || []).filter(sf => !sf.isCompleted).forEach(sf => {
            acc[sf.findingCategory] = (acc[sf.findingCategory] || 0) + 1;
        });
        return acc;
    }, {} as Record<FindingCategoryLevel, number>);

    const legacyOccurrenceCounts = operators.reduce((acc, op) => {
        (op.legacyRiskFactors.occurrences || []).forEach(occ => {
            acc[occ.type] = (acc[occ.type] || 0) + 1;
        });
        return acc;
    }, {} as Record<string, number>);


    const context = `
      Overall Operator Risk Profile:
      ${Object.entries(idrDistribution).map(([level, count]) => `- ${count} operators at ${level}`).join('\n')}

      Top 5 Surveillance Findings (Last Year):
      ${topSurveillanceFindings.map(f => `- "${f.finding}" (Count: ${f.count})`).join('\n') || "No recent findings."}

      Open Surveillance Findings by Category:
      ${Object.entries(openFindingsByCategory).map(([cat, count]) => `- ${cat}: ${count}`).join('\n') || "No open findings."}
      
      Total Legacy Occurrences by Type:
      ${Object.entries(legacyOccurrenceCounts).map(([type, count]) => `- ${type}: ${count}`).join('\n') || "No legacy occurrences."}
    `;

    const prompt = `
      You are a strategic advisor to the DGCA of Indonesia. Based on the following aggregated data trends across all AOC holders,
      provide a concise set of 3-5 high-level, actionable recommendations for the DGCA.
      Focus on systemic issues, potential areas for focused oversight, safety promotion, or regulatory attention.
      Avoid using markdown for emphasis (like asterisks for bolding). Provide a plain text response, well-formatted with bullet points or numbered lists for clarity.

      Aggregated Data Context:
      ${context}

      Recommendations for DGCA:
    `;

    try {
      const response: GenerateContentResponse = await aiDashboardClient.models.generateContent({
        model: 'gemini-2.5-flash-preview-04-17',
        contents: prompt,
      });
      setAiAdvisory(response.text);
    } catch (error: any) {
      console.error("Error querying Gemini API for dashboard advisory:", error);
      setAiAdvisoryError(`Failed to get recommendations: ${error.message || 'Unknown AI error.'}`);
      setAiAdvisory('');
    } finally {
      setIsAiAdvisoryLoading(false);
    }
  };


  if (operators === undefined && !isImporting) { 
    return <LoadingSpinner />;
  }
  
  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-center gap-3">
        <h2 className="text-2xl font-bold text-slate-800">RBS - Operator Dashboard</h2>
        <div className="flex space-x-2">
            <input 
                type="file" 
                accept=".csv" 
                ref={fileInputRef} 
                onChange={handleFileUpload} 
                className="hidden" 
                disabled={isImporting}
            />
            <button
                onClick={handleImportButtonClick}
                className="bg-green-600 hover:bg-green-700 text-white font-semibold py-2 px-3 rounded-lg shadow-sm hover:shadow-lg transition-all flex items-center text-sm"
                disabled={isImporting}
            >
                {isImporting ? <LoadingSpinner size="sm" /> : <UploadIcon className="h-4 w-4 mr-1.5" />}
                {isImporting ? 'Importing...' : 'Import CSV'}
            </button>
            <Link
            to="/operator/new"
            className="bg-brand-primary hover:bg-blue-800 text-white font-semibold py-2 px-3 rounded-lg shadow-sm hover:shadow-lg transition-all flex items-center text-sm"
            >
            <PlusIcon className="h-4 w-4 mr-1.5" /> Add New Operator
            </Link>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Operator Performance Overview Chart */}
        <div className="lg:col-span-2 bg-white p-4 sm:p-6 rounded-xl shadow-lg">
          <h3 className="text-lg font-semibold text-slate-700 mb-3 flex items-center">
              <ChartBarIcon className="h-5 w-5 mr-2 text-brand-secondary" />
              Operator Performance Overview (Top 10 by Risk)
          </h3>
          {operators.length > 0 ? (
          <ResponsiveContainer width="100%" height={300}>
              <BarChart data={chartData} margin={{ top: 5, right: 0, left: -10, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" angle={-35} textAnchor="end" height={75} interval={0} tick={{fontSize: 9}} />
              <YAxis tick={{fontSize: 10}} label={{ value: 'Performance Score F(P) %', angle: -90, position: 'insideLeft', fontSize: 10, offset:10 }} />
              <Tooltip 
                  contentStyle={{backgroundColor: 'rgba(255,255,255,0.9)', border: '1px solid #ccc', borderRadius: '5px', fontSize: '10px', padding: '5px'}}
                  labelStyle={{color: '#333', fontWeight: 'bold'}}
                  formatter={(value: number, name: string, props) => [`${value.toFixed(1)}% (IDR: ${props.payload.riskIndicatorLevel}, Exp: ${props.payload.exposureLevel})`, "F(P) Score"]}
              />
              <Legend wrapperStyle={{fontSize: "10px"}}/>
              <Bar dataKey="performanceScore" name="Performance Score F(P)">
                  {chartData.map((entry, index) => (
                       <Cell key={`cell-${index}`} fill={entry.fill} />
                  ))}
              </Bar>
              </BarChart>
          </ResponsiveContainer>
          ) : (
              <p className="text-slate-500 text-sm">No operator data available. Add operators to see the risk overview.</p>
          )}
        </div>

        {/* Top Surveillance Findings */}
        <div className="lg:col-span-1 bg-white p-4 sm:p-6 rounded-xl shadow-lg">
            <h3 className="text-lg font-semibold text-slate-700 mb-4">Top Surveillance Findings (Last Year)</h3>
            {topSurveillanceFindings.length > 0 ? (
                <ul className="space-y-2">
                    {topSurveillanceFindings.map((item, index) => (
                        <li key={index} className="text-xs p-2 rounded-md bg-slate-50 border border-slate-200">
                            <span className="font-semibold text-slate-600 block capitalize">{item.finding}</span>
                            <span className="text-brand-secondary">Count: {item.count}</span>
                        </li>
                    ))}
                </ul>
            ) : (
                <p className="text-slate-500 text-sm italic">No surveillance findings recorded in the last year.</p>
            )}
        </div>
      </div>
      
      {/* AI-Powered DGCA Advisory */}
        <div className="bg-white p-4 sm:p-6 rounded-xl shadow-lg">
            <h3 className="text-lg font-semibold text-slate-700 mb-3 flex items-center">
                <InformationCircleIcon className="h-5 w-5 mr-2 text-brand-secondary" />
                AI-Powered DGCA Advisory
            </h3>
            {!API_KEY && (
                <div className="p-3 text-sm text-yellow-700 bg-yellow-100 rounded-md border border-yellow-300">
                    AI Advisory feature is unavailable. API_KEY is not configured.
                </div>
            )}
            {API_KEY && !aiDashboardClient && aiAdvisoryError &&(
                 <div className="p-3 text-sm text-red-700 bg-red-100 rounded-md border border-red-300">
                    {aiAdvisoryError}
                </div>
            )}
            {API_KEY && !aiDashboardClient && !aiAdvisoryError && (
                <div className="p-3 text-sm text-blue-700 bg-blue-100 rounded-md border border-blue-300 flex items-center">
                   <LoadingSpinner size="sm"/> <span className="ml-2">Initializing AI Advisory service...</span>
                </div>
            )}
            {API_KEY && aiDashboardClient && (
                <>
                    <button
                        onClick={handleGenerateOverallRecommendations}
                        disabled={isAiAdvisoryLoading || operators.length === 0}
                        className="bg-sky-600 hover:bg-sky-700 text-white font-semibold py-2 px-4 rounded-lg shadow-sm transition-all flex items-center text-sm disabled:bg-slate-400 disabled:cursor-not-allowed"
                    >
                        {isAiAdvisoryLoading ? (
                            <> <LoadingSpinner size="sm" /> <span className="ml-2">Generating...</span> </>
                        ) : (
                            "Generate Overall Recommendations"
                        )}
                    </button>
                    {isAiAdvisoryLoading && <div className="mt-3"><LoadingSpinner /></div>}
                    {aiAdvisoryError && !isAiAdvisoryLoading && (
                        <div className="mt-3 p-3 text-sm text-red-700 bg-red-100 rounded-md border border-red-300">
                            <p className="font-semibold">Error generating advisory:</p>
                            <p>{aiAdvisoryError}</p>
                        </div>
                    )}
                    {aiAdvisory && !isAiAdvisoryLoading && (
                        <div className="mt-4 p-3 bg-slate-50 border border-slate-200 rounded-md">
                            <h4 className="text-md font-semibold text-slate-800 mb-2">DGCA Recommendations:</h4>
                            <pre className="whitespace-pre-wrap text-sm text-slate-700 font-sans leading-relaxed">{aiAdvisory}</pre>
                        </div>
                    )}
                    {operators.length === 0 && !isAiAdvisoryLoading && (
                        <p className="text-slate-500 text-sm italic mt-2">Add operator data to generate recommendations.</p>
                    )}
                </>
            )}
        </div>


      <div>
        <input 
            type="text"
            placeholder="Search operators by name or AOC..."
            className="w-full p-2.5 border border-slate-300 rounded-lg shadow-sm focus:ring-1 focus:ring-brand-secondary focus:border-transparent outline-none text-sm"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
        />
      </div>

      {filteredOperators.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {filteredOperators.map((operator) => (
            <OperatorCard key={operator.id} operator={operator} />
          ))}
        </div>
      ) : (
        <div className="text-center py-10">
          <svg className="mx-auto h-10 w-10 text-slate-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true">
            <path vectorEffect="non-scaling-stroke" strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 13h6m-3-3v6m-9 1V7a2 2 0 012-2h6l2 2h6a2 2 0 012 2v8a2 2 0 01-2 2H5a2 2 0 01-2-2z" />
          </svg>
          <h3 className="mt-2 text-md font-medium text-slate-800">No Operators Found</h3>
          <p className="mt-1 text-xs text-slate-500">
            {searchTerm ? "Adjust your search criteria or " : ""}
            Get started by <Link to="/operator/new" className="font-medium text-brand-primary hover:text-blue-800">adding a new operator</Link>.
          </p>
        </div>
      )}
    </div>
  );
};

