
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useOperators } from '../hooks/useOperators';
import { 
    Operator, 
    DEFAULT_COMPLEXITY_FACTORS,
    DEFAULT_COMPLIANCE_DATA,
    DEFAULT_DEVIATION_DATA,
    DEFAULT_IMPROVEMENT_DATA,
    DEFAULT_LEGACY_RISK_FACTORS
} from '../types';
import toast from 'react-hot-toast';

export const AddOperatorPage: React.FC = () => {
  const navigate = useNavigate();
  const { addOperator } = useOperators();
  const [name, setName] = useState('');
  const [aocNumber, setAocNumber] = useState('');

  // State for Compliance Findings
  const [ncp, setNcp] = useState(0);
  const [ncf, setNcf] = useState(0);
  const [nad, setNad] = useState(0);
  const [totalChecklistItems, setTotalChecklistItems] = useState(100); // Default, can be adjusted by user

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !aocNumber.trim()) {
      toast.error('Operator Name and AOC Number are required.');
      return;
    }
    if (totalChecklistItems <= 0) {
      toast.error('Total Checklist Items must be greater than 0.');
      return;
    }

    const newOperatorData: Pick<Operator, 'name' | 'aocNumber'> & Partial<Pick<Operator, 'complexityFactors' | 'complianceData' | 'deviationData' | 'improvementData' | 'legacyRiskFactors'>> = {
      name,
      aocNumber,
      complianceData: {
        findings: { ncp, ncf, nad },
        totalChecklistItems,
      },
      complexityFactors: { ...DEFAULT_COMPLEXITY_FACTORS },
      deviationData: { ...DEFAULT_DEVIATION_DATA },
      improvementData: { ...DEFAULT_IMPROVEMENT_DATA },
      legacyRiskFactors: { ...DEFAULT_LEGACY_RISK_FACTORS }, 
    };
    
    const addedOp = addOperator(newOperatorData);
    navigate(`/operator/${addedOp.id}`); 
  };

  return (
    <div className="max-w-2xl mx-auto bg-white p-6 sm:p-8 rounded-xl shadow-xl">
      <h2 className="text-2xl sm:text-3xl font-bold text-slate-800 mb-6 sm:mb-8">Add New Operator</h2>
      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <label htmlFor="name" className="block text-sm font-medium text-slate-700 mb-1">
            Operator Name
          </label>
          <input
            type="text"
            id="name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="w-full p-3 border border-slate-300 rounded-lg shadow-sm focus:ring-2 focus:ring-brand-secondary focus:border-transparent outline-none"
            required
            aria-label="Operator Name"
          />
        </div>
        <div>
          <label htmlFor="aocNumber" className="block text-sm font-medium text-slate-700 mb-1">
            AOC Number
          </label>
          <input
            type="text"
            id="aocNumber"
            value={aocNumber}
            onChange={(e) => setAocNumber(e.target.value)}
            className="w-full p-3 border border-slate-300 rounded-lg shadow-sm focus:ring-2 focus:ring-brand-secondary focus:border-transparent outline-none"
            required
            aria-label="AOC Number"
          />
        </div>

        {/* Compliance Findings Section */}
        <div className="pt-4">
          <h3 className="text-xl font-semibold text-slate-700 mb-4 border-b pb-2">Compliance Findings</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-4">
            <div>
              <label htmlFor="ncp" className="block text-sm font-medium text-slate-700 mb-1">
                NCP (Non-Compliance) Count
              </label>
              <input
                type="number"
                id="ncp"
                value={ncp}
                onChange={(e) => setNcp(Math.max(0, parseInt(e.target.value, 10) || 0))}
                className="w-full p-3 border border-slate-300 rounded-lg shadow-sm focus:ring-2 focus:ring-brand-secondary focus:border-transparent outline-none"
                min="0"
                aria-label="NCP Count"
              />
            </div>
            <div>
              <label htmlFor="ncf" className="block text-sm font-medium text-slate-700 mb-1">
                NCF (Non-Conformance) Count
              </label>
              <input
                type="number"
                id="ncf"
                value={ncf}
                onChange={(e) => setNcf(Math.max(0, parseInt(e.target.value, 10) || 0))}
                className="w-full p-3 border border-slate-300 rounded-lg shadow-sm focus:ring-2 focus:ring-brand-secondary focus:border-transparent outline-none"
                min="0"
                aria-label="NCF Count"
              />
            </div>
            <div>
              <label htmlFor="nad" className="block text-sm font-medium text-slate-700 mb-1">
                NAD (Non-Adherence) Count
              </label>
              <input
                type="number"
                id="nad"
                value={nad}
                onChange={(e) => setNad(Math.max(0, parseInt(e.target.value, 10) || 0))}
                className="w-full p-3 border border-slate-300 rounded-lg shadow-sm focus:ring-2 focus:ring-brand-secondary focus:border-transparent outline-none"
                min="0"
                aria-label="NAD Count"
              />
            </div>
            <div>
              <label htmlFor="totalChecklistItems" className="block text-sm font-medium text-slate-700 mb-1">
                Total Checklist Items (N<sub>checklist</sub>)
              </label>
              <input
                type="number"
                id="totalChecklistItems"
                value={totalChecklistItems}
                onChange={(e) => setTotalChecklistItems(Math.max(1, parseInt(e.target.value, 10) || 1))}
                className="w-full p-3 border border-slate-300 rounded-lg shadow-sm focus:ring-2 focus:ring-brand-secondary focus:border-transparent outline-none"
                min="1"
                aria-label="Total Checklist Items"
              />
            </div>
          </div>
        </div>
        
        <div className="pt-2 text-xs text-slate-500">
            <p>Initial values for other Risk-Based Surveillance (RBS) data (Complexity, Deviation, Improvement factors) will be set to defaults. You can edit these on the operator's detail page after creation.</p>
        </div>

        <div className="flex justify-end space-x-3 pt-4">
          <button
            type="button"
            onClick={() => navigate('/')}
            className="px-6 py-2.5 border border-slate-300 text-slate-700 font-medium rounded-lg shadow-sm hover:bg-slate-50 transition-colors"
          >
            Cancel
          </button>
          <button
            type="submit"
            className="px-6 py-2.5 bg-brand-primary hover:bg-blue-800 text-white font-semibold rounded-lg shadow-md hover:shadow-lg transition-all"
          >
            Add Operator
          </button>
        </div>
      </form>
    </div>
  );
};
