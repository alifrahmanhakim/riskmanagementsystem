
import React, { useState, useEffect, useMemo } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { useOperators } from '../hooks/useOperators';
import { 
    Operator, 
    Occurrence, 
    OccurrenceType, 
    SeverityLevel, 
    RiskLevel,
    ComplexityFactors,
    ComplianceData,
    ComplianceFindingCounts, 
    DeviationData,
    ImprovementData,
    SurveillanceFinding,
    FindingCategoryLevel, 
    DEFAULT_SURVEILLANCE_FINDING_FORM_STATE,
    DEFAULT_COMPLEXITY_FACTORS,
    DEFAULT_COMPLIANCE_DATA,
    DEFAULT_DEVIATION_DATA,
    DEFAULT_IMPROVEMENT_DATA,
    ExposureLevel
} from '../types';
import { LoadingSpinner } from '../components/shared/LoadingSpinner';
import { RiskBadge } from '../components/shared/RiskBadge'; 
import { Modal } from '../components/shared/Modal';
import { PencilIcon, TrashIcon, PlusIcon, ExclamationTriangleIcon, CheckCircleIcon, XCircleIcon, InformationCircleIcon } from '../components/icons';
import toast from 'react-hot-toast';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend } from 'recharts';
import { CHART_HEX_RISK_LEVEL_COLORS, CHART_HEX_EXPOSURE_LEVEL_COLORS, RBS_MATRIX_CELL_KEYS, RBS_PERFORMANCE_TO_INDICATOR_LEVEL, FINDING_CATEGORY_OPTIONS, CHART_HEX_SURVEILLANCE_STATUS_COLORS } from '../constants';
import { GoogleGenAI, GenerateContentResponse } from '@google/genai';


const initialLegacyOccurrenceFormState = {
  date: new Date().toISOString().split('T')[0],
  type: OccurrenceType.INCIDENT,
  severity: SeverityLevel.LOW,
  description: '',
};

export const OperatorDetailPage: React.FC = () => {
  const { operatorId } = useParams<{ operatorId: string }>();
  const navigate = useNavigate();
  const { 
    operators, 
    getOperatorById, 
    updateOperatorBasicInfo,
    updateOperatorRBSData,
    deleteOperator, 
    addLegacyOccurrence, 
    updateLegacyOccurrence, 
    deleteLegacyOccurrence,
    addSurveillanceFinding,
    updateSurveillanceFinding,
    deleteSurveillanceFinding,
    toggleSurveillanceFindingCompletion 
  } = useOperators();

  const [operator, setOperator] = useState<Operator | null | undefined>(undefined);
  const [isEditingBasicInfo, setIsEditingBasicInfo] = useState(false);
  
  const [basicInfoForm, setBasicInfoForm] = useState({ name: '', aocNumber: '', logoUrl: '' });
  const [complexityFactorsForm, setComplexityFactorsForm] = useState<ComplexityFactors>(DEFAULT_COMPLEXITY_FACTORS);
  const [complianceDataForm, setComplianceDataForm] = useState<ComplianceData>(DEFAULT_COMPLIANCE_DATA);
  const [deviationDataForm, setDeviationDataForm] = useState<DeviationData>(DEFAULT_DEVIATION_DATA);
  const [improvementDataForm, setImprovementDataForm] = useState<ImprovementData>(DEFAULT_IMPROVEMENT_DATA);

  const [isLegacyOccurrenceModalOpen, setIsLegacyOccurrenceModalOpen] = useState(false);
  const [editingLegacyOccurrence, setEditingLegacyOccurrence] = useState<Occurrence | null>(null);
  const [legacyOccurrenceFormData, setLegacyOccurrenceFormData] = useState<Omit<Occurrence, 'id'>>(initialLegacyOccurrenceFormState);

  // Surveillance Finding State
  const [isSurveillanceFindingModalOpen, setIsSurveillanceFindingModalOpen] = useState(false);
  const [editingSurveillanceFinding, setEditingSurveillanceFinding] = useState<SurveillanceFinding | null>(null);
  const [surveillanceFindingFormData, setSurveillanceFindingFormData] = useState<Omit<SurveillanceFinding, 'id' | 'isCompleted' | 'dateAdded' | 'actualCompletionDate' | 'targetCompletionDate'>>(DEFAULT_SURVEILLANCE_FINDING_FORM_STATE);


  // Gemini AI State
  const [aiClient, setAiClient] = useState<GoogleGenAI | null>(null);
  const [aiQuery, setAiQuery] = useState('');
  const [aiResponse, setAiResponse] = useState('');
  const [isAiLoading, setIsAiLoading] = useState(false);
  const [aiError, setAiError] = useState<string | null>(null);
  const API_KEY = process.env.API_KEY;


  useEffect(() => {
    if (operatorId) {
      const foundOperator = getOperatorById(operatorId);
      setOperator(foundOperator);
      if (foundOperator) {
        setBasicInfoForm({ name: foundOperator.name, aocNumber: foundOperator.aocNumber, logoUrl: foundOperator.logoUrl || '' });
        setComplexityFactorsForm(foundOperator.complexityFactors);
        setComplianceDataForm(foundOperator.complianceData);
        setDeviationDataForm(foundOperator.deviationData);
        setImprovementDataForm(foundOperator.improvementData);
      }
    }
  }, [operatorId, getOperatorById, operators]); 

  useEffect(() => {
    if (API_KEY) {
      try {
        const client = new GoogleGenAI({ apiKey: API_KEY });
        setAiClient(client);
        setAiError(null); 
      } catch (error) {
        console.error("Failed to initialize GoogleGenAI client:", error);
        setAiError("Failed to initialize AI client. Check API key configuration and network.");
        setAiClient(null);
      }
    } else {
      setAiClient(null); 
    }
  }, [API_KEY]);


  const handleBasicInfoSave = () => {
    if (operator && basicInfoForm.name.trim() && basicInfoForm.aocNumber.trim()) {
      updateOperatorBasicInfo(operator.id, { name: basicInfoForm.name, aocNumber: basicInfoForm.aocNumber, logoUrl: basicInfoForm.logoUrl });
      setIsEditingBasicInfo(false);
    } else {
      toast.error("Name and AOC number cannot be empty.");
    }
  };

  const handleRBSDataSave = () => {
    if (!operator) return;
    updateOperatorRBSData(operator.id, {
        complexityFactors: complexityFactorsForm,
        complianceData: complianceDataForm,
        deviationData: deviationDataForm,
        improvementData: improvementDataForm,
    });
  };
  
  const handleDeleteOperator = () => {
    if (operator && window.confirm(`Are you sure you want to delete operator "${operator.name}"? This action cannot be undone.`)) {
      deleteOperator(operator.id);
      navigate('/');
    }
  };

  const openAddLegacyOccurrenceModal = () => {
    setEditingLegacyOccurrence(null);
    setLegacyOccurrenceFormData(initialLegacyOccurrenceFormState);
    setIsLegacyOccurrenceModalOpen(true);
  };

  const openEditLegacyOccurrenceModal = (occurrence: Occurrence) => {
    setEditingLegacyOccurrence(occurrence);
    setLegacyOccurrenceFormData({
      date: occurrence.date.split('T')[0], 
      type: occurrence.type,
      severity: occurrence.severity,
      description: occurrence.description,
    });
    setIsLegacyOccurrenceModalOpen(true);
  };

  const handleLegacyOccurrenceFormChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setLegacyOccurrenceFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleLegacyOccurrenceSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!operator) return;
    if(!legacyOccurrenceFormData.description.trim()){
        toast.error("Description is required for an occurrence.");
        return;
    }
    if (editingLegacyOccurrence) {
      updateLegacyOccurrence(operator.id, editingLegacyOccurrence.id, legacyOccurrenceFormData);
    } else {
      addLegacyOccurrence(operator.id, legacyOccurrenceFormData);
    }
    setIsLegacyOccurrenceModalOpen(false);
  };

  const deleteLegacyOcc = (occurrenceId: string) => {
    if (operator && window.confirm("Are you sure you want to delete this legacy occurrence?")) {
      deleteLegacyOccurrence(operator.id, occurrenceId);
    }
  };

  // Surveillance Finding Modal and Form Handlers
  const openAddSurveillanceFindingModal = () => {
    setEditingSurveillanceFinding(null);
    setSurveillanceFindingFormData(DEFAULT_SURVEILLANCE_FINDING_FORM_STATE);
    setIsSurveillanceFindingModalOpen(true);
  };

  const openEditSurveillanceFindingModal = (finding: SurveillanceFinding) => {
    setEditingSurveillanceFinding(finding);
    setSurveillanceFindingFormData({
      finding: finding.finding,
      findingCategory: finding.findingCategory,
      rootCauseAnalysis: finding.rootCauseAnalysis,
      correctiveActionPlan: finding.correctiveActionPlan,
      correctiveActionTaken: finding.correctiveActionTaken,
      // targetCompletionDate is now calculated, not set in form
    });
    setIsSurveillanceFindingModalOpen(true);
  };

  const handleSurveillanceFindingFormChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setSurveillanceFindingFormData(prev => ({ ...prev, [name]: value }));
  };
  

  const handleSurveillanceFindingSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!operator) return;
    if (!surveillanceFindingFormData.finding.trim() || !surveillanceFindingFormData.findingCategory) {
        toast.error("Finding description and Finding Category are required.");
        return;
    }
    const dataToSubmit = {
        finding: surveillanceFindingFormData.finding,
        findingCategory: surveillanceFindingFormData.findingCategory,
        rootCauseAnalysis: surveillanceFindingFormData.rootCauseAnalysis,
        correctiveActionPlan: surveillanceFindingFormData.correctiveActionPlan,
        correctiveActionTaken: surveillanceFindingFormData.correctiveActionTaken,
    };

    if (editingSurveillanceFinding) {
      updateSurveillanceFinding(operator.id, editingSurveillanceFinding.id, {
          ...dataToSubmit,
          isCompleted: editingSurveillanceFinding.isCompleted 
      });
    } else {
      addSurveillanceFinding(operator.id, dataToSubmit);
    }
    setIsSurveillanceFindingModalOpen(false);
  };

  const handleDeleteFinding = (findingId: string) => {
    if (operator && window.confirm("Are you sure you want to delete this surveillance finding?")) {
      deleteSurveillanceFinding(operator.id, findingId);
    }
  };

  const handleToggleFindingCompletion = (findingId: string) => {
    if (operator) {
      toggleSurveillanceFindingCompletion(operator.id, findingId);
    }
  };


  const handleAiQuerySubmit = async () => {
    if (!aiClient) {
      setAiError("AI client is not initialized. Please ensure the API key is correctly configured.");
      return;
    }
    if (!aiQuery.trim()) {
      setAiError("Please enter a query for the AI assistant.");
      return;
    }
    if (!operator) {
      setAiError("Operator data not available for context.");
      return;
    }

    setIsAiLoading(true);
    setAiResponse('');
    setAiError(null);

    let surveillanceFindingsContext = "\nSurveillance Findings Log:\n";
    if (operator.surveillanceFindings && operator.surveillanceFindings.length > 0) {
      operator.surveillanceFindings.forEach(sf => {
        surveillanceFindingsContext += `- Finding: "${sf.finding}" (Category: ${sf.findingCategory}, Target: ${new Date(sf.targetCompletionDate).toLocaleDateString()}, Status: ${sf.isCompleted ? `Completed on ${sf.actualCompletionDate ? new Date(sf.actualCompletionDate).toLocaleDateString() : 'N/A'}` : 'Open'})\n  RCA: ${sf.rootCauseAnalysis || 'N/A'}\n  CAP: ${sf.correctiveActionPlan || 'N/A'}\n`;
      });
    } else {
      surveillanceFindingsContext += "No surveillance findings recorded.\n";
    }

    let legacyOccurrencesContext = "\nLegacy Occurrences Log:\n";
    if (operator.legacyRiskFactors.occurrences && operator.legacyRiskFactors.occurrences.length > 0) {
      operator.legacyRiskFactors.occurrences.forEach(occ => {
        legacyOccurrencesContext += `- Date: ${new Date(occ.date).toLocaleDateString()}, Type: ${occ.type}, Severity: ${occ.severity}, Desc: "${occ.description}"\n`;
      });
    } else {
      legacyOccurrencesContext += "No legacy occurrences recorded.\n";
    }

    const operatorContext = `
      Operator Name: ${operator.name}
      AOC Number: ${operator.aocNumber}
      Exposure Level: ${operator.exposureLevel} (Score: ${operator.exposureScore})
      Risk Indicator Level (IDR): ${operator.riskIndicatorLevel}
      Overall Performance Score (F(P)): ${(operator.overallPerformanceScore * 100).toFixed(2)}%
      Suggested Surveillance Cycle: ${operator.suggestedSurveillanceCycleMonths} Months
      Compliance Factor Score (C(p)): ${(operator.complianceFactorScore * 100).toFixed(1)}% (Source: ${operator.surveillanceFindings && operator.surveillanceFindings.filter(sf => !sf.isCompleted).length > 0 ? 'Open Surveillance Findings' : 'Manual Compliance Data'})
      Deviation Factor Score (D(p)): ${(operator.deviationFactorScore * 10000).toFixed(3)} per 10k cycles (raw: ${operator.deviationFactorScore.toFixed(5)})
      Improvement Factor Score (I(p)): ${(operator.improvementFactorScore * 100).toFixed(1)}%
      ${surveillanceFindingsContext}
      ${legacyOccurrencesContext}
    `;

    const prompt = `
      You are an AI assistant for aviation risk management specialists at a regulatory body like the DGCA.
      Your goal is to provide concise, insightful, and actionable information based on the provided operator data and the user's query.
      Focus on safety, risk assessment, compliance with aviation regulations (e.g., ICAO standards, local CASRs), and potential areas for surveillance or investigation.
      Consider the operator's surveillance findings (including their category and target dates) and legacy occurrences if they seem relevant to the user's query.
      Avoid using markdown for emphasis (like asterisks for bolding). Provide a plain text response.
      
      Operator Context:
      ${operatorContext}

      User Query:
      "${aiQuery}"

      Based on this context and query, please provide your analysis. Be specific and practical. If regulatory documents are relevant, mention them.
    `;

    try {
      const response: GenerateContentResponse = await aiClient.models.generateContent({
        model: 'gemini-2.5-flash-preview-04-17',
        contents: prompt,
      });
      setAiResponse(response.text);
    } catch (error: any) {
      console.error("Error querying Gemini API:", error);
      setAiError(`Failed to get response from AI: ${error.message || 'Unknown error. Check console for details.'}`);
      setAiResponse('');
    } finally {
      setIsAiLoading(false);
    }
  };

  const legacyOccurrenceSeverityData = useMemo(() => {
    if (!operator || !operator.legacyRiskFactors) return [];
    const counts = operator.legacyRiskFactors.occurrences.reduce((acc, occ) => {
      acc[occ.severity] = (acc[occ.severity] || 0) + 1;
      return acc;
    }, {} as Record<SeverityLevel, number>);
    return Object.entries(counts).map(([name, value]) => ({ name: name as SeverityLevel, value }));
  }, [operator]);

  const surveillanceFindingStatusData = useMemo(() => {
    if (!operator || !operator.surveillanceFindings) return [];
    const openCount = operator.surveillanceFindings.filter(sf => !sf.isCompleted).length;
    const completedCount = operator.surveillanceFindings.filter(sf => sf.isCompleted).length;
    return [
        { name: 'Open', value: openCount, color: CHART_HEX_SURVEILLANCE_STATUS_COLORS.OPEN },
        { name: 'Completed', value: completedCount, color: CHART_HEX_SURVEILLANCE_STATUS_COLORS.COMPLETED },
    ].filter(d => d.value > 0); // Only show slices with value > 0
  }, [operator]);

  const usesDynamicComplianceFactor = useMemo(() => {
    return operator?.surveillanceFindings && operator.surveillanceFindings.filter(sf => !sf.isCompleted).length > 0;
  }, [operator]);


  if (operator === undefined && !API_KEY) { 
      return <div className="flex justify-center items-center h-64"><LoadingSpinner size="lg" /></div>;
  }
  if (operator === undefined && API_KEY && !aiClient && !aiError) { 
      return <div className="flex justify-center items-center h-64"><LoadingSpinner size="lg" /><p className="ml-2">Initializing systems...</p></div>;
  }
  if (operator === null) return (
    <div className="text-center py-12">
      <ExclamationTriangleIcon className="mx-auto h-16 w-16 text-red-500" />
      <h2 className="mt-4 text-2xl font-bold text-slate-700">Operator Not Found</h2>
      <Link to="/" className="mt-6 inline-block bg-brand-primary hover:bg-blue-800 text-white font-semibold py-2 px-4 rounded-lg">Go to Dashboard</Link>
    </div>
  );


  const riskIndicatorLabel = RBS_PERFORMANCE_TO_INDICATOR_LEVEL.find(item => item.level === operator?.riskIndicatorLevel)?.label || "N/A";
  const exposureLevelColor = CHART_HEX_EXPOSURE_LEVEL_COLORS[operator?.exposureLevel || ExposureLevel.A] || '#ccc';


  const createNumberInput = (id: keyof ComplexityFactors | keyof ComplianceData | keyof ComplianceFindingCounts | keyof DeviationData | keyof ImprovementData, value: number, category: string, subCategory?: string) => {
    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const numValue = e.target.value === '' ? 0 : Number(e.target.value);
        if (category === 'complexity') setComplexityFactorsForm(prev => ({...prev, [id as keyof ComplexityFactors]: numValue}));
        else if (category === 'compliance' && subCategory === 'findings') setComplianceDataForm(prev => ({...prev, findings: {...prev.findings, [id as keyof ComplianceFindingCounts]: numValue}}));
        else if (category === 'compliance') setComplianceDataForm(prev => ({...prev, [id as keyof ComplianceData]: numValue}));
        else if (category === 'deviation') setDeviationDataForm(prev => ({...prev, [id as keyof DeviationData]: numValue}));
        else if (category === 'improvement') setImprovementDataForm(prev => ({...prev, [id as keyof ImprovementData]: numValue}));
    };
    return <input type="number" id={String(id)} value={value} onChange={handleChange} className="mt-1 block w-full p-2 border border-slate-300 rounded-md shadow-sm text-sm"/>;
  };


  return (
    <div className="space-y-6">
      {/* Operator Basic Info */}
      <div className="bg-white shadow-xl rounded-xl p-6">
        <div className="flex flex-col sm:flex-row justify-between items-start mb-4">
            <div className="flex items-center mb-4 sm:mb-0">
                {operator?.logoUrl && <img src={operator.logoUrl} alt={`${operator.name} logo`} className="h-16 w-auto mr-4 rounded border p-1" />}
                <div>
                    <h2 className="text-2xl font-bold text-brand-primary">{operator?.name}</h2>
                    <p className="text-slate-600">AOC: {operator?.aocNumber}</p>
                </div>
            </div>
            <div className="text-right">
                <p className="text-sm text-slate-500">Suggested Surveillance Cycle:</p>
                <p className="text-2xl font-bold text-brand-secondary">{operator?.suggestedSurveillanceCycleMonths} Months</p>
                <p className="text-xs text-slate-500">Matrix Key: {operator?.finalRiskCategoryKey}</p>
            </div>
        </div>
        <div className="flex space-x-2">
            <button onClick={() => setIsEditingBasicInfo(!isEditingBasicInfo)} className="text-sm bg-sky-500 hover:bg-sky-600 text-white font-medium py-1.5 px-3 rounded-md flex items-center">
                <PencilIcon className="h-4 w-4 mr-1"/> {isEditingBasicInfo ? 'Cancel' : 'Edit Info'}
            </button>
            <button onClick={handleDeleteOperator} className="text-sm bg-red-500 hover:bg-red-600 text-white font-medium py-1.5 px-3 rounded-md flex items-center">
                <TrashIcon className="h-4 w-4 mr-1"/> Delete Operator
            </button>
        </div>
        {isEditingBasicInfo && operator && (
          <div className="mt-4 p-3 border border-sky-200 rounded-lg bg-sky-50 space-y-3">
            <div><label className="text-xs font-medium">Name</label><input type="text" value={basicInfoForm.name} onChange={e => setBasicInfoForm({...basicInfoForm, name: e.target.value})} className="w-full p-1.5 border rounded-md text-sm"/></div>
            <div><label className="text-xs font-medium">AOC</label><input type="text" value={basicInfoForm.aocNumber} onChange={e => setBasicInfoForm({...basicInfoForm, aocNumber: e.target.value})} className="w-full p-1.5 border rounded-md text-sm"/></div>
            <div><label className="text-xs font-medium">Logo URL</label><input type="text" value={basicInfoForm.logoUrl} onChange={e => setBasicInfoForm({...basicInfoForm, logoUrl: e.target.value})} className="w-full p-1.5 border rounded-md text-sm"/></div>
            <button onClick={handleBasicInfoSave} className="text-sm bg-green-500 hover:bg-green-600 text-white py-1.5 px-3 rounded-md">Save Info</button>
          </div>
        )}
      </div>

      {/* RBS Scores Overview */}
      {operator && (
        <div className="bg-white shadow-xl rounded-xl p-6 grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
            <div><p className="text-xs text-slate-500">Exposure Level</p><p className="text-lg font-bold" style={{color: exposureLevelColor}}>{operator.exposureLevel} ({operator.exposureScore})</p></div>
            <div><p className="text-xs text-slate-500">Risk Indicator Level (IDR)</p><p className="text-lg font-bold text-slate-700">{operator.riskIndicatorLevel} <span className="text-xs font-normal">({riskIndicatorLabel})</span></p></div>
            <div><p className="text-xs text-slate-500">Performance Score (F(P))</p><p className="text-lg font-bold text-slate-700">{(operator.overallPerformanceScore * 100).toFixed(2)}%</p></div>
            <div className="grid grid-cols-3 gap-1 text-xs">
                <div title={usesDynamicComplianceFactor ? "C(p) derived from open surveillance findings" : "C(p) from manual compliance data"}>
                    <p className="text-slate-500 flex items-center justify-center">C(p) {usesDynamicComplianceFactor && <InformationCircleIcon className="h-3 w-3 ml-0.5 text-blue-500" />}</p>
                    <p className="font-medium">{(operator.complianceFactorScore*100).toFixed(1)}%</p>
                </div>
                <div><p className="text-slate-500">D(p)</p><p className="font-medium">{(operator.deviationFactorScore*100).toFixed(3)}%</p></div>
                <div><p className="text-slate-500">I(p)</p><p className="font-medium">{(operator.improvementFactorScore*100).toFixed(1)}%</p></div>
            </div>
        </div>
      )}
      
      {/* AI Research Assistant */}
      <div className="bg-white shadow-xl rounded-xl p-6">
        <h3 className="text-xl font-semibold text-slate-700 mb-4">AI Research Assistant</h3>
        {!API_KEY && (
            <div className="p-4 mb-4 text-sm text-yellow-800 rounded-lg bg-yellow-50 dark:bg-gray-800 dark:text-yellow-300" role="alert">
            <span className="font-medium">AI Feature Not Available:</span> The API key (<code>process.env.API_KEY</code>) is not configured. 
            Please set it up to use the AI research assistant.
            </div>
        )}
        {API_KEY && !aiClient && aiError && ( 
            <div className="p-4 mb-4 text-sm text-red-800 rounded-lg bg-red-50" role="alert">
                <span className="font-medium">AI Initialization Error:</span> {aiError}
            </div>
        )}
        {API_KEY && !aiClient && !aiError && ( 
            <div className="p-4 mb-4 text-sm text-blue-800 rounded-lg bg-blue-50 flex items-center" role="status">
                <LoadingSpinner size="sm" /> <span className="ml-2">Initializing AI Assistant...</span>
            </div>
        )}
        {API_KEY && aiClient && operator && (
            <div className="space-y-3">
            <div>
                <label htmlFor="aiQuery" className="block text-sm font-medium text-slate-700">
                Ask the AI about this operator (e.g., "Common risks for operators with similar exposure?", "Relevant ICAO annexes for compliance issues?"):
                </label>
                <textarea
                id="aiQuery"
                rows={3}
                className="mt-1 block w-full p-2 border border-slate-300 rounded-md shadow-sm focus:ring-brand-secondary focus:border-brand-secondary sm:text-sm disabled:bg-slate-100 disabled:text-slate-500 disabled:cursor-not-allowed"
                value={aiQuery}
                onChange={(e) => setAiQuery(e.target.value)}
                placeholder="Type your query here..."
                disabled={isAiLoading || !aiClient}
                />
            </div>
            <button
                onClick={handleAiQuerySubmit}
                disabled={isAiLoading || !aiClient || !aiQuery.trim()}
                className="px-4 py-2 bg-brand-primary text-white text-sm font-medium rounded-md shadow-sm hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-brand-secondary disabled:bg-slate-400 disabled:cursor-not-allowed flex items-center justify-center min-w-[100px]"
                aria-live="polite"
            >
                {isAiLoading ? (
                <>
                    <LoadingSpinner size="sm" />
                    <span className="ml-2">Thinking...</span>
                </>
                ) : (
                "Ask AI"
                )}
            </button>

            {aiError && !isAiLoading && ( 
                <div className="mt-3 p-3 text-sm text-red-700 bg-red-100 rounded-md border border-red-300" role="alert">
                <p className="font-semibold">AI Error:</p>
                <p>{aiError}</p>
                </div>
            )}

            {aiResponse && !isAiLoading && (
                <div className="mt-4 p-4 bg-slate-50 border border-slate-200 rounded-md">
                <h4 className="text-md font-semibold text-slate-800 mb-2">AI Assistant Response:</h4>
                <pre className="whitespace-pre-wrap text-sm text-slate-700 font-sans leading-relaxed">{aiResponse}</pre>
                </div>
            )}
            </div>
        )}
      </div>

      {/* RBS Matrix */}
      {operator && (
          <div className="bg-white shadow-xl rounded-xl p-6">
            <h3 className="text-lg font-semibold text-slate-700 mb-3">Risk-Based Surveillance Matrix</h3>
            <div className="overflow-x-auto">
                <table className="border-collapse border border-slate-300 w-full text-center text-xs">
                    <thead>
                        <tr>
                            <th className="border border-slate-300 p-1 bg-slate-100" colSpan={2}></th>
                            <th className="border border-slate-300 p-1 bg-slate-100" colSpan={5}>Risk Indicator Level (frekuensi RBS)</th>
                        </tr>
                        <tr>
                            <th className="border border-slate-300 p-1 bg-slate-100" colSpan={2}>Exposure (FIde)</th>
                            {[1,2,3,4,5].map(ril => <th key={ril} className="border border-slate-300 p-1 bg-slate-100 w-1/6">{ril} ({RBS_PERFORMANCE_TO_INDICATOR_LEVEL.find(i=>i.level===ril)?.label.split(' ')[0]})</th>)}
                        </tr>
                    </thead>
                    <tbody>
                        {Object.values(ExposureLevel).map(el => (
                            <tr key={el}>
                                <td className="border border-slate-300 p-1 bg-slate-100 font-semibold w-auto whitespace-nowrap" style={{minWidth: '100px'}}>{el}</td>
                                <td className="border border-slate-300 p-1 bg-slate-50 text-xxs w-auto whitespace-nowrap" style={{minWidth: '100px'}}>({el === ExposureLevel.A ? 'Sgt Rendah' : el === ExposureLevel.B ? 'Rendah' : el === ExposureLevel.C ? 'Sedang' : el === ExposureLevel.D ? 'Tinggi' : 'Sgt Tinggi'})</td>
                                {[1,2,3,4,5].map(ril => {
                                    const cellKey = RBS_MATRIX_CELL_KEYS[el]?.[ril] || '';
                                    const isActive = cellKey === operator.finalRiskCategoryKey;
                                    return (
                                        <td key={`${el}-${ril}`} className={`border border-slate-300 p-2 ${isActive ? 'bg-brand-secondary text-white font-bold ring-2 ring-yellow-400' : 'bg-white'}`}>
                                            {cellKey}
                                        </td>
                                    );
                                })}
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
      )}
      
      {/* RBS Data Inputs */}
      {operator && (
        <div className="bg-white shadow-xl rounded-xl p-6">
            <h3 className="text-xl font-semibold text-slate-700 mb-4">Operator Data for RBS Calculation</h3>
            {usesDynamicComplianceFactor && (
                <div className="p-3 mb-4 text-xs text-blue-700 bg-blue-100 rounded-md border border-blue-300 flex items-center">
                    <InformationCircleIcon className="h-4 w-4 mr-2 text-blue-500" />
                    Compliance Factor C(p) is currently being calculated dynamically based on open items in the Surveillance Findings Log. Manual NCP/NCF/NAD counts below are used if the log is empty.
                </div>
            )}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-x-6 gap-y-4 text-sm">
                <section className="space-y-2 p-3 border rounded-md bg-slate-50">
                    <h4 className="font-semibold text-slate-600">Complexity Factors</h4>
                    <div><label>Annual Flight Count</label>{createNumberInput('annualFlightCount', complexityFactorsForm.annualFlightCount, 'complexity')}</div>
                    <div><label>Num Employees</label>{createNumberInput('numEmployees', complexityFactorsForm.numEmployees, 'complexity')}</div>
                    <div><label>Num Aircraft</label>{createNumberInput('numAircraft', complexityFactorsForm.numAircraft, 'complexity')}</div>
                    <div><label>Num Aircraft Models</label>{createNumberInput('numAircraftModels', complexityFactorsForm.numAircraftModels, 'complexity')}</div>
                    <div><label>Num Destinations</label>{createNumberInput('numDestinations', complexityFactorsForm.numDestinations, 'complexity')}</div>
                    <div><label>Avg Fleet Age</label>{createNumberInput('avgFleetAge', complexityFactorsForm.avgFleetAge, 'complexity')}</div>
                    <div><label>Num Domestic Bases</label>{createNumberInput('numDomesticBases', complexityFactorsForm.numDomesticBases, 'complexity')}</div>
                    <div><label className="block">International Ops?</label>
                        <select value={String(complexityFactorsForm.hasInternationalOps)} onChange={e => setComplexityFactorsForm(prev => ({...prev, hasInternationalOps: e.target.value === 'true'}))} className="w-full p-1.5 border rounded-md text-sm bg-white">
                            <option value="true">Yes</option><option value="false">No</option>
                        </select>
                    </div>
                </section>

                <section className="space-y-2 p-3 border rounded-md bg-slate-50">
                    <h4 className="font-semibold text-slate-600">Compliance Data (Fallback)</h4>
                    <div><label>NCP Findings</label>{createNumberInput('ncp', complianceDataForm.findings.ncp, 'compliance', 'findings')}</div>
                    <div><label>NCF Findings</label>{createNumberInput('ncf', complianceDataForm.findings.ncf, 'compliance', 'findings')}</div>
                    <div><label>NAD Findings</label>{createNumberInput('nad', complianceDataForm.findings.nad, 'compliance', 'findings')}</div>
                    <div><label>Total Checklist Items</label>{createNumberInput('totalChecklistItems', complianceDataForm.totalChecklistItems, 'compliance')}</div>
                </section>

                <section className="space-y-2 p-3 border rounded-md bg-slate-50">
                    <h4 className="font-semibold text-slate-600">Deviation Data</h4>
                    <div><label>Accident Count</label>{createNumberInput('accidentCount', deviationDataForm.accidentCount, 'deviation')}</div>
                    <div><label>Serious Incident Count</label>{createNumberInput('seriousIncidentCount', deviationDataForm.seriousIncidentCount, 'deviation')}</div>
                    <div><label>Incident Count</label>{createNumberInput('incidentCount', deviationDataForm.incidentCount, 'deviation')}</div>
                    <div><label>Total Flight Cycles</label>{createNumberInput('totalFlightCycles', deviationDataForm.totalFlightCycles, 'deviation')}</div>
                </section>

                <section className="space-y-2 p-3 border rounded-md bg-slate-50">
                    <h4 className="font-semibold text-slate-600">Improvement Data (Simplified)</h4>
                    <div><label>Total Deviations (Nd)</label>{createNumberInput('totalDeviationsNd', improvementDataForm.totalDeviationsNd, 'improvement')}</div>
                    <div><label>Total Findings (Nf)</label>{createNumberInput('totalFindingsNf', improvementDataForm.totalFindingsNf, 'improvement')}</div>
                    <p className="text-xs text-slate-500 mt-1">Corrective Actions (Counts by highest stage achieved):</p>
                    <div><label>Root Cause Identified</label>{createNumberInput('correctiveActionsRootCause', improvementDataForm.correctiveActionsRootCause, 'improvement')}</div>
                    <div><label>Hazard Identified</label>{createNumberInput('correctiveActionsHazardIdentified', improvementDataForm.correctiveActionsHazardIdentified, 'improvement')}</div>
                    <div><label>Risk Assessed</label>{createNumberInput('correctiveActionsRiskAssessed', improvementDataForm.correctiveActionsRiskAssessed, 'improvement')}</div>
                    <div><label>Risk Mitigated</label>{createNumberInput('correctiveActionsRiskMitigated', improvementDataForm.correctiveActionsRiskMitigated, 'improvement')}</div>
                </section>
            </div>
            <div className="mt-6 flex justify-end">
                <button onClick={handleRBSDataSave} className="bg-brand-secondary hover:bg-sky-700 text-white font-semibold py-2 px-4 rounded-lg shadow-md">
                    Update & Recalculate RBS Profile
                </button>
            </div>
          </div>
      )}

        {/* Surveillance Findings Log */}
        {operator && (
            <div className="bg-white shadow-xl rounded-xl p-6">
            <div className="flex justify-between items-center mb-4">
                <h3 className="text-xl font-semibold text-slate-700">Surveillance Findings Log ({operator.surveillanceFindings?.length || 0})</h3>
                <button onClick={openAddSurveillanceFindingModal} className="text-sm bg-teal-500 hover:bg-teal-600 text-white font-medium py-2 px-4 rounded-lg shadow-md flex items-center">
                <PlusIcon className="h-4 w-4 mr-1.5" /> Add Finding
                </button>
            </div>
            {operator.surveillanceFindings && operator.surveillanceFindings.length > 0 ? (
                <>
                    <div className="overflow-x-auto">
                        <table className="min-w-full divide-y divide-slate-200 text-xs">
                            <thead className="bg-slate-50">
                            <tr>
                                <th className="px-3 py-2 text-left font-medium text-slate-500">Date Added</th>
                                <th className="px-3 py-2 text-left font-medium text-slate-500">Finding</th>
                                <th className="px-3 py-2 text-left font-medium text-slate-500">Category</th>
                                <th className="px-3 py-2 text-left font-medium text-slate-500">RCA</th>
                                <th className="px-3 py-2 text-left font-medium text-slate-500">CAP</th>
                                <th className="px-3 py-2 text-left font-medium text-slate-500">Action Taken</th>
                                <th className="px-3 py-2 text-left font-medium text-slate-500">Target Date</th>
                                <th className="px-3 py-2 text-left font-medium text-slate-500">Status</th>
                                <th className="px-3 py-2 text-left font-medium text-slate-500">Actions</th>
                            </tr>
                            </thead>
                            <tbody className="bg-white divide-y divide-slate-200">
                            {operator.surveillanceFindings.sort((a,b) => new Date(b.dateAdded).getTime() - new Date(a.dateAdded).getTime()).map(sf => {
                                const isOverdue = !sf.isCompleted && new Date(sf.targetCompletionDate) < new Date();
                                return (
                                <tr key={sf.id}>
                                    <td className="px-3 py-2 whitespace-nowrap text-slate-700">{new Date(sf.dateAdded).toLocaleDateString()}</td>
                                    <td className="px-3 py-2 text-slate-600 max-w-[150px] truncate" title={sf.finding}>{sf.finding}</td>
                                    <td className="px-3 py-2 text-slate-600 whitespace-nowrap">{sf.findingCategory.split(' ')[0]} {sf.findingCategory.split(' ')[1]}</td>
                                    <td className="px-3 py-2 text-slate-600 max-w-[100px] truncate" title={sf.rootCauseAnalysis}>{sf.rootCauseAnalysis}</td>
                                    <td className="px-3 py-2 text-slate-600 max-w-[100px] truncate" title={sf.correctiveActionPlan}>{sf.correctiveActionPlan}</td>
                                    <td className="px-3 py-2 text-slate-600 max-w-[100px] truncate" title={sf.correctiveActionTaken}>{sf.correctiveActionTaken}</td>
                                    <td className={`px-3 py-2 whitespace-nowrap text-slate-700 ${isOverdue ? 'text-red-600 font-semibold animate-pulse' : ''}`}>
                                        {new Date(sf.targetCompletionDate).toLocaleDateString()}
                                        {isOverdue && <ExclamationTriangleIcon className="h-3 w-3 inline ml-1 text-red-600" title="Overdue"/>}
                                    </td>
                                    <td className="px-3 py-2 whitespace-nowrap">
                                    {sf.isCompleted ? 
                                        <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                                            <CheckCircleIcon className="h-3 w-3 mr-1"/> Completed
                                            {sf.actualCompletionDate && <span className="ml-1 text-xxs">({new Date(sf.actualCompletionDate).toLocaleDateString()})</span>}
                                        </span> : 
                                        <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800">
                                            <XCircleIcon className="h-3 w-3 mr-1"/> Open
                                        </span>
                                    }
                                    </td>
                                    <td className="px-3 py-2 whitespace-nowrap font-medium space-x-1">
                                    <button onClick={() => openEditSurveillanceFindingModal(sf)} className="text-brand-secondary hover:text-sky-700 p-0.5" title="Edit Finding"><PencilIcon className="h-4 w-4"/></button>
                                    <button onClick={() => handleDeleteFinding(sf.id)} className="text-red-500 hover:text-red-700 p-0.5" title="Delete Finding"><TrashIcon className="h-4 w-4"/></button>
                                    <button 
                                        onClick={() => handleToggleFindingCompletion(sf.id)} 
                                        className={`p-0.5 rounded ${sf.isCompleted ? 'text-yellow-500 hover:text-yellow-700' : 'text-green-500 hover:text-green-700'}`}
                                        title={sf.isCompleted ? "Mark as Open" : "Mark as Completed"}
                                    >
                                        {sf.isCompleted ? <XCircleIcon className="h-4 w-4"/> : <CheckCircleIcon className="h-4 w-4"/>}
                                    </button>
                                    </td>
                                </tr>
                                );
                            })}
                            </tbody>
                        </table>
                    </div>
                    <div className="mt-6">
                        <h4 className="text-md font-semibold text-slate-700 mb-3">Findings Status Distribution</h4>
                        <ResponsiveContainer width="100%" height={250}>
                            <PieChart>
                                <Pie
                                    data={surveillanceFindingStatusData}
                                    cx="50%"
                                    cy="50%"
                                    labelLine={false}
                                    label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                                    outerRadius={80}
                                    fill="#8884d8"
                                    dataKey="value"
                                >
                                    {surveillanceFindingStatusData.map((entry) => (
                                        <Cell key={`cell-${entry.name}`} fill={entry.color} />
                                    ))}
                                </Pie>
                                <Tooltip contentStyle={{fontSize: '12px', padding: '4px 8px'}} />
                                <Legend wrapperStyle={{fontSize: "12px"}}/>
                            </PieChart>
                        </ResponsiveContainer>
                    </div>
                </>
            ) : <p className="text-slate-500 italic text-sm">No surveillance findings recorded for this operator.</p>}
            </div>
        )}

      {/* Legacy Occurrences Log */}
      {operator && (
          <div className="bg-white shadow-xl rounded-xl p-6">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-semibold text-slate-700">Legacy Occurrences Log ({operator.legacyRiskFactors.occurrences.length})</h3>
              <button onClick={openAddLegacyOccurrenceModal} className="text-sm bg-green-500 hover:bg-green-600 text-white font-medium py-1.5 px-3 rounded-md flex items-center">
                <PlusIcon className="h-4 w-4 mr-1" /> Add Legacy Occurrence
              </button>
            </div>
            {operator.legacyRiskFactors.occurrences.length > 0 ? (
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-slate-200 text-xs">
                  <thead className="bg-slate-50">
                    <tr>
                      <th scope="col" className="px-3 py-2 text-left font-medium text-slate-500 uppercase">Date</th>
                      <th scope="col" className="px-3 py-2 text-left font-medium text-slate-500 uppercase">Type</th>
                      <th scope="col" className="px-3 py-2 text-left font-medium text-slate-500 uppercase">Severity</th>
                      <th scope="col" className="px-3 py-2 text-left font-medium text-slate-500 uppercase">Description</th>
                      <th scope="col" className="px-3 py-2 text-left font-medium text-slate-500 uppercase">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-slate-200">
                    {operator.legacyRiskFactors.occurrences.sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime()).map(occ => (
                      <tr key={occ.id}>
                        <td className="px-3 py-2 whitespace-nowrap text-slate-700">{new Date(occ.date).toLocaleDateString()}</td>
                        <td className="px-3 py-2 whitespace-nowrap text-slate-700">{occ.type}</td>
                        <td className="px-3 py-2 whitespace-nowrap"><RiskBadge level={occ.severity as unknown as RiskLevel} size="sm" /></td>
                        <td className="px-3 py-2 text-slate-600 max-w-xs truncate" title={occ.description}>{occ.description}</td>
                        <td className="px-3 py-2 whitespace-nowrap font-medium space-x-1">
                          <button onClick={() => openEditLegacyOccurrenceModal(occ)} className="text-brand-secondary hover:text-sky-700 p-0.5"><PencilIcon className="h-4 w-4"/></button>
                          <button onClick={() => deleteLegacyOcc(occ.id)} className="text-red-500 hover:text-red-700 p-0.5"><TrashIcon className="h-4 w-4"/></button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : <p className="text-slate-500 italic text-sm">No legacy occurrences recorded.</p>}
            {operator.legacyRiskFactors.occurrences.length > 0 && (
                <div className="mt-4">
                    <h4 className="text-sm font-semibold text-slate-700 mb-2">Legacy Occurrence Severity Distribution</h4>
                    <ResponsiveContainer width="100%" height={200}>
                        <PieChart>
                            <Pie data={legacyOccurrenceSeverityData} cx="50%" cy="50%" labelLine={false} label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`} outerRadius={60} fill="#8884d8" dataKey="value">
                                {legacyOccurrenceSeverityData.map((entry, index) => (
                                    <Cell key={`cell-${index}`} fill={CHART_HEX_RISK_LEVEL_COLORS[entry.name as unknown as RiskLevel] || '#808080'} />
                                ))}
                            </Pie>
                            <Tooltip contentStyle={{fontSize: '10px', padding: '2px 4px'}}/>
                            <Legend wrapperStyle={{fontSize: '10px'}}/>
                        </PieChart>
                    </ResponsiveContainer>
                </div>
            )}
          </div>
      )}

      {/* Legacy Occurrence Modal */}
      <Modal isOpen={isLegacyOccurrenceModalOpen} onClose={() => setIsLegacyOccurrenceModalOpen(false)} title={editingLegacyOccurrence ? 'Edit Legacy Occurrence' : 'Add Legacy Occurrence'} size="md">
        <form onSubmit={handleLegacyOccurrenceSubmit} className="space-y-3 text-sm">
          <div><label className="block font-medium">Date</label><input type="date" name="date" value={legacyOccurrenceFormData.date} onChange={handleLegacyOccurrenceFormChange} required className="w-full p-1.5 border rounded"/></div>
          <div><label className="block font-medium">Type</label><select name="type" value={legacyOccurrenceFormData.type} onChange={handleLegacyOccurrenceFormChange} required className="w-full p-1.5 border rounded bg-white">{Object.values(OccurrenceType).map(type => <option key={type} value={type}>{type}</option>)}</select></div>
          <div><label className="block font-medium">Severity</label><select name="severity" value={legacyOccurrenceFormData.severity} onChange={handleLegacyOccurrenceFormChange} required className="w-full p-1.5 border rounded bg-white">{Object.values(SeverityLevel).map(level => <option key={level} value={level}>{level}</option>)}</select></div>
          <div><label className="block font-medium">Description</label><textarea name="description" value={legacyOccurrenceFormData.description} onChange={handleLegacyOccurrenceFormChange} rows={3} required className="w-full p-1.5 border rounded"></textarea></div>
          <div className="flex justify-end space-x-2 pt-1"><button type="button" onClick={() => setIsLegacyOccurrenceModalOpen(false)} className="px-3 py-1.5 border rounded hover:bg-slate-50">Cancel</button><button type="submit" className="px-3 py-1.5 bg-brand-primary text-white rounded hover:bg-blue-800">{editingLegacyOccurrence ? 'Save Changes' : 'Add Occurrence'}</button></div>
        </form>
      </Modal>

      {/* Surveillance Finding Modal */}
      <Modal isOpen={isSurveillanceFindingModalOpen} onClose={() => setIsSurveillanceFindingModalOpen(false)} title={editingSurveillanceFinding ? 'Edit Surveillance Finding' : 'Add Surveillance Finding'} size="lg">
        <form onSubmit={handleSurveillanceFindingSubmit} className="space-y-4 text-sm">
          <div>
            <label htmlFor="finding" className="block font-medium text-slate-700">Finding</label>
            <textarea id="finding" name="finding" value={surveillanceFindingFormData.finding} onChange={handleSurveillanceFindingFormChange} required rows={3} className="w-full p-2 border rounded-md mt-1 shadow-sm focus:ring-brand-secondary focus:border-brand-secondary"></textarea>
          </div>
          <div>
            <label htmlFor="findingCategory" className="block font-medium text-slate-700">Finding Category</label>
            <select 
              id="findingCategory" 
              name="findingCategory" 
              value={surveillanceFindingFormData.findingCategory} 
              onChange={handleSurveillanceFindingFormChange} 
              required 
              className="w-full p-2 border rounded-md mt-1 shadow-sm focus:ring-brand-secondary focus:border-brand-secondary bg-white"
            >
              {FINDING_CATEGORY_OPTIONS.map(opt => (
                <option key={opt.value} value={opt.value}>{opt.label}</option>
              ))}
            </select>
          </div>
          <div>
            <label htmlFor="rootCauseAnalysis" className="block font-medium text-slate-700">Root Cause Analysis (RCA)</label>
            <textarea id="rootCauseAnalysis" name="rootCauseAnalysis" value={surveillanceFindingFormData.rootCauseAnalysis} onChange={handleSurveillanceFindingFormChange} rows={3} className="w-full p-2 border rounded-md mt-1 shadow-sm focus:ring-brand-secondary focus:border-brand-secondary"></textarea>
          </div>
          <div>
            <label htmlFor="correctiveActionPlan" className="block font-medium text-slate-700">Corrective Action Plan (CAP)</label>
            <textarea id="correctiveActionPlan" name="correctiveActionPlan" value={surveillanceFindingFormData.correctiveActionPlan} onChange={handleSurveillanceFindingFormChange} rows={3} className="w-full p-2 border rounded-md mt-1 shadow-sm focus:ring-brand-secondary focus:border-brand-secondary"></textarea>
          </div>
          <div>
            <label htmlFor="correctiveActionTaken" className="block font-medium text-slate-700">Corrective Action Taken</label>
            <textarea id="correctiveActionTaken" name="correctiveActionTaken" value={surveillanceFindingFormData.correctiveActionTaken} onChange={handleSurveillanceFindingFormChange} rows={3} className="w-full p-2 border rounded-md mt-1 shadow-sm focus:ring-brand-secondary focus:border-brand-secondary"></textarea>
          </div>
          
          {editingSurveillanceFinding && (
            <div className="flex items-center">
              <input 
                type="checkbox" 
                id="isCompleted" 
                name="isCompleted" 
                checked={editingSurveillanceFinding.isCompleted} 
                onChange={() => handleToggleFindingCompletion(editingSurveillanceFinding.id)} 
                className="h-4 w-4 text-brand-primary border-slate-300 rounded focus:ring-brand-secondary mr-2"
              />
              <label htmlFor="isCompleted" className="font-medium text-slate-700">Mark as Completed</label>
            </div>
          )}

          <div className="flex justify-end space-x-3 pt-2">
            <button type="button" onClick={() => setIsSurveillanceFindingModalOpen(false)} className="px-4 py-2 border border-slate-300 rounded-md shadow-sm hover:bg-slate-50 text-slate-700">Cancel</button>
            <button type="submit" className="px-4 py-2 bg-brand-primary text-white rounded-md shadow-sm hover:bg-blue-700">{editingSurveillanceFinding ? 'Save Changes' : 'Add Finding'}</button>
          </div>
        </form>
      </Modal>
    </div>
  );
};
