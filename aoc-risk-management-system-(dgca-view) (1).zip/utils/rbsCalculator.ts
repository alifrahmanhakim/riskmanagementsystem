import { 
  Operator, 
  ComplexityFactors, 
  ComplianceData, 
  DeviationData, 
  ImprovementData, 
  ExposureLevel,
  RiskLevel,
  SurveillanceFinding,
  FindingCategoryLevel
} from '../types';
import {
  RBS_WEIGHT_COMPLIANCE,
  RBS_WEIGHT_DEVIATION,
  RBS_WEIGHT_IMPROVEMENT,
  RBS_COMPLIANCE_FINDING_WEIGHTS,
  RBS_DEVIATION_CATEGORY_WEIGHTS,
  RBS_CORRECTIVE_ACTION_WEIGHTS,
  RBS_PERFORMANCE_TO_INDICATOR_LEVEL,
  RBS_MATRIX_SURVEILLANCE_CYCLES,
  RBS_MATRIX_CELL_KEYS
} from '../constants';

// --- RBS Calculation Functions ---

// 1. Calculate Exposure Score and Level (Slide 30)
export const calculateExposureProfile = (cf: ComplexityFactors): { score: number, level: ExposureLevel } => {
  let score = 0;

  // Jumlah penerbangan tahunan
  if (cf.annualFlightCount > 45000) score += 3;
  else if (cf.annualFlightCount >= 4000) score += 2; // Slide says 4000 to 45000
  else if (cf.annualFlightCount > 0) score += 1; // Slide says Kurang dari 4000

  // Jumlah Karyawan
  if (cf.numEmployees > 100) score += 3;
  else if (cf.numEmployees >= 10) score += 2; // Slide says 10 to 100
  else if (cf.numEmployees > 0)score += 1; // Slide says 1 to 10

  // Jumlah pesawat
  if (cf.numAircraft > 10) score += 3;
  else if (cf.numAircraft >= 4) score += 2;
  else if (cf.numAircraft > 0) score += 1;

  // Jumlah model pesawat
  if (cf.numAircraftModels > 5) score += 3;
  else if (cf.numAircraftModels >= 2) score += 2;
  else if (cf.numAircraftModels > 0) score += 1;
  
  // Jumlah tujuan
  if (cf.numDestinations > 50) score += 3;
  else if (cf.numDestinations >= 11) score += 2;
  else if (cf.numDestinations > 0) score += 1;

  // Operasi internasional
  if (cf.hasInternationalOps) score += 2;
  else score += 1;

  // Usia armada rata-rata
  if (cf.avgFleetAge > 15) score += 3;
  else if (cf.avgFleetAge >= 5) score += 2;
  else if (cf.avgFleetAge >= 0) score += 1; // Assuming age cannot be negative

  // Jumlah pangkalan domestik
  if (cf.numDomesticBases > 10) score += 3;
  else if (cf.numDomesticBases >= 2) score += 2;
  else if (cf.numDomesticBases > 0) score += 1;
  
  let level: ExposureLevel;
  if (score < 10) level = ExposureLevel.A;       // 8 < 10 on slide
  else if (score < 12) level = ExposureLevel.B;  // 10 < 12
  else if (score < 14) level = ExposureLevel.C;  // 12 < 14
  else if (score < 16) level = ExposureLevel.D;  // 14 < 16
  else level = ExposureLevel.E;                  // 16 < 24 (or >=16)

  return { score, level };
};

export const calculateComplianceFactorScore = (
  complianceData: ComplianceData,
  surveillanceFindings?: SurveillanceFinding[]
): number => {
  if (complianceData.totalChecklistItems === 0) return 0;

  let ncp = 0;
  let ncf = 0;
  let nad = 0;

  const openFindings = surveillanceFindings?.filter(sf => !sf.isCompleted) || [];

  if (openFindings.length > 0) {
    ncp = openFindings.filter(sf => sf.findingCategory === FindingCategoryLevel.LEVEL_1).length;
    ncf = openFindings.filter(sf => sf.findingCategory === FindingCategoryLevel.LEVEL_2).length;
    nad = openFindings.filter(sf => sf.findingCategory === FindingCategoryLevel.LEVEL_3).length;
  } else {
    ncp = complianceData.findings.ncp;
    ncf = complianceData.findings.ncf;
    nad = complianceData.findings.nad;
  }

  const Mf = (ncp * RBS_COMPLIANCE_FINDING_WEIGHTS.ncp) +
             (ncf * RBS_COMPLIANCE_FINDING_WEIGHTS.ncf) +
             (nad * RBS_COMPLIANCE_FINDING_WEIGHTS.nad);
             
  const xc = Mf / complianceData.totalChecklistItems;
  return Math.max(0, Math.min(1, 1 - xc)); // Clamp between 0 and 1
};


// 3. Calculate Deviation Factor D(p) (Slide 20)
export const calculateDeviationFactorScore = (data: DeviationData): number => {
  if (data.totalFlightCycles === 0) return 1; 
  const weightedDeviations = 
    (data.accidentCount * RBS_DEVIATION_CATEGORY_WEIGHTS.accident) +
    (data.seriousIncidentCount * RBS_DEVIATION_CATEGORY_WEIGHTS.seriousIncident) +
    (data.incidentCount * RBS_DEVIATION_CATEGORY_WEIGHTS.incident);
  
  const score = weightedDeviations / data.totalFlightCycles;
  return Math.max(0, score); 
};

// 4. Calculate Improvement Factor I(p) (Slide 21)
export const calculateImprovementFactorScore = (data: ImprovementData): number => {
  const Nf = data.totalFindingsNf;
  const Nd = data.totalDeviationsNd;

  if (Nf + Nd === 0) return 1; // Perfect improvement if nothing to improve
  
  let sumWeightedEffectiveness = 0;
  sumWeightedEffectiveness += data.correctiveActionsRootCause * RBS_CORRECTIVE_ACTION_WEIGHTS.rootCause;
  sumWeightedEffectiveness += data.correctiveActionsHazardIdentified * RBS_CORRECTIVE_ACTION_WEIGHTS.hazardIdentified;
  sumWeightedEffectiveness += data.correctiveActionsRiskAssessed * RBS_CORRECTIVE_ACTION_WEIGHTS.riskAssessed;
  sumWeightedEffectiveness += data.correctiveActionsRiskMitigated * RBS_CORRECTIVE_ACTION_WEIGHTS.riskMitigated;
  
  const totalItemsWithCorrectiveActions = data.correctiveActionsRootCause +
                                        data.correctiveActionsHazardIdentified +
                                        data.correctiveActionsRiskAssessed +
                                        data.correctiveActionsRiskMitigated;

  if (totalItemsWithCorrectiveActions === 0) {
      return (Nf + Nd === 0) ? 1 : 0;
  }
  
  // Simplistic: Assume totalIssues requiring CA is Nf + Nd.
  // Improvement is the proportion of issues that are fully mitigated.
  const totalIssues = Nd + Nf;
  if (totalIssues === 0) return 1.0; 
  const mitigatedIssues = data.correctiveActionsRiskMitigated; 
  return Math.min(1, Math.max(0, mitigatedIssues / totalIssues));
};


// 5. Calculate Overall Performance Score F(P) (Slide 17)
export const calculateOverallPerformanceScore = (
  cp: number, 
  dp: number, 
  ip: number  
): number => {
  const performanceScore = (RBS_WEIGHT_COMPLIANCE * cp) - 
                           (RBS_WEIGHT_DEVIATION * dp) + 
                           (RBS_WEIGHT_IMPROVEMENT * ip);
  return Math.max(0, Math.min(1, performanceScore)); // Clamp to 0-1 range
};

// 6. Map F(P) to Risk Indicator Level (IDR 1-5) (Slide 29)
export const getRiskIndicatorLevel = (performanceScore: number): { level: number, label: string } => {
  const scorePercent = performanceScore * 100;
  for (const range of RBS_PERFORMANCE_TO_INDICATOR_LEVEL) { 
    if (scorePercent <= range.thresholdMax) { 
      const lowerBoundEntry = RBS_PERFORMANCE_TO_INDICATOR_LEVEL.find(r => r.level === range.level + 1);
      const lowerBound = lowerBoundEntry ? lowerBoundEntry.thresholdMax : -Infinity; // For level 5, lower bound is effectively -infinity

      if (range.level === 5 && scorePercent >=0 && scorePercent <= range.thresholdMax) { // Level 5: 0-35
        return { level: range.level, label: range.label };
      }
      if (scorePercent > lowerBound && scorePercent <= range.thresholdMax) {
         return { level: range.level, label: range.label }; 
      }
    }
  }
   // Default for scores > last explicitly defined thresholdMax (e.g. > 85 for level 1)
  const highestLevelEntry = RBS_PERFORMANCE_TO_INDICATOR_LEVEL[RBS_PERFORMANCE_TO_INDICATOR_LEVEL.length -1];
  if (scorePercent > highestLevelEntry.thresholdMax) {
    return { level: highestLevelEntry.level, label: highestLevelEntry.label };
  }

  return { level: 1, label: "Sangat Rendah ORP" }; // Fallback default
};


// 7. Determine Final Risk Category Key and Surveillance Cycle (Slide 26/31 Matrix)
export const getSurveillanceCycle = (
  exposureLevel: ExposureLevel, 
  riskIndicatorLevel: number 
): { cycleMonths: number, categoryKey: string } => {
  const matrixRow = RBS_MATRIX_CELL_KEYS[exposureLevel];
  if (!matrixRow) return { cycleMonths: 12, categoryKey: "N/A" }; 

  const categoryKey = matrixRow[riskIndicatorLevel];
  if (!categoryKey) return { cycleMonths: 12, categoryKey: "N/A" };

  const cycleMonths = RBS_MATRIX_SURVEILLANCE_CYCLES[categoryKey] || 12; 
  return { cycleMonths, categoryKey };
};


// Main function to update all RBS calculations for an operator
export const calculateAllRbsMetrics = (operator: Operator): Partial<Operator> => {
  const exposure = calculateExposureProfile(operator.complexityFactors);
  // Pass surveillanceFindings to calculateComplianceFactorScore
  const cp = calculateComplianceFactorScore(operator.complianceData, operator.surveillanceFindings);
  const dp = calculateDeviationFactorScore(operator.deviationData);
  const ip = calculateImprovementFactorScore(operator.improvementData);
  
  const overallPerformanceScore = calculateOverallPerformanceScore(cp, dp, ip);
  const riskIndicator = getRiskIndicatorLevel(overallPerformanceScore);
  const surveillance = getSurveillanceCycle(exposure.level, riskIndicator.level);

  return {
    exposureScore: exposure.score,
    exposureLevel: exposure.level,
    complianceFactorScore: cp,
    deviationFactorScore: dp,
    improvementFactorScore: ip,
    overallPerformanceScore: overallPerformanceScore,
    riskIndicatorLevel: riskIndicator.level,
    finalRiskCategoryKey: surveillance.categoryKey,
    suggestedSurveillanceCycleMonths: surveillance.cycleMonths,
  };
};
