
import React, { createContext, useContext, useEffect, useCallback, ReactNode } from 'react';
import { 
    Operator,
    LegacyRiskFactors,
    Occurrence, 
    RiskLevel, 
    OccurrenceType, 
    SeverityLevel,
    ComplexityFactors,
    ComplianceData,
    DeviationData,
    ImprovementData,
    SurveillanceFinding,
    FindingCategoryLevel,
    DEFAULT_COMPLEXITY_FACTORS,
    DEFAULT_COMPLIANCE_DATA,
    DEFAULT_DEVIATION_DATA,
    DEFAULT_IMPROVEMENT_DATA,
    DEFAULT_LEGACY_RISK_FACTORS,
    ExposureLevel
} from '../types';
import useLocalStorage from './useLocalStorage';
import { updatedOperatorLegacyRiskProfile } from '../utils/riskCalculator'; // Legacy
import { calculateAllRbsMetrics } from '../utils/rbsCalculator'; // New RBS
import { MOCK_OPERATOR_LOGOS, FINDING_CATEGORY_TARGET_DAYS } from '../constants';
import toast from 'react-hot-toast';

interface OperatorContextType {
  operators: Operator[];
  getOperatorById: (id: string) => Operator | undefined;
  addOperator: (operatorData: Pick<Operator, 'name' | 'aocNumber'> & Partial<Pick<Operator, 'complexityFactors' | 'complianceData' | 'deviationData' | 'improvementData' | 'legacyRiskFactors' | 'surveillanceFindings'>>) => Operator;
  updateOperatorBasicInfo: (id: string, basicInfo: Pick<Operator, 'name' | 'aocNumber' | 'logoUrl'>) => void;
  updateOperatorRBSData: (
    id: string, 
    data: {
      complexityFactors?: Partial<ComplexityFactors>;
      complianceData?: Partial<ComplianceData>;
      deviationData?: Partial<DeviationData>;
      improvementData?: Partial<ImprovementData>;
    }
  ) => void;
  deleteOperator: (id: string) => void;
  addLegacyOccurrence: (operatorId: string, occurrenceData: Omit<Occurrence, 'id'>) => void;
  updateLegacyOccurrence: (operatorId: string, occurrenceId: string, updatedOccurrenceData: Partial<Omit<Occurrence, 'id'>>) => void;
  deleteLegacyOccurrence: (operatorId: string, occurrenceId: string) => void;

  // Surveillance Findings
  addSurveillanceFinding: (operatorId: string, findingData: Omit<SurveillanceFinding, 'id' | 'isCompleted' | 'dateAdded' | 'actualCompletionDate' | 'targetCompletionDate'>) => void;
  updateSurveillanceFinding: (operatorId: string, findingId: string, updatedData: Partial<Omit<SurveillanceFinding, 'id' | 'dateAdded' | 'actualCompletionDate' | 'targetCompletionDate'>>) => void;
  deleteSurveillanceFinding: (operatorId: string, findingId: string) => void;
  toggleSurveillanceFindingCompletion: (operatorId: string, findingId: string) => void;
}

const OperatorContext = createContext<OperatorContextType | undefined>(undefined);

const initialOperators: Operator[] = [
].map(op => enrichOperatorWithRBS(op as Operator)); 


function enrichOperatorWithRBS(operator: Operator): Operator {
  const rbsMetrics = calculateAllRbsMetrics(operator);
  const legacyProfile = updatedOperatorLegacyRiskProfile(operator); 

  return {
    ...operator,
    ...rbsMetrics,
    legacyOverallRiskScore: legacyProfile.legacyOverallRiskScore,
    legacyOverallRiskLevel: legacyProfile.legacyOverallRiskLevel,
    surveillanceFindings: operator.surveillanceFindings?.map(sf => ({
      ...sf,
      targetCompletionDate: calculateTargetDate(sf.dateAdded, sf.findingCategory) 
    })) || [],
    lastUpdated: new Date().toISOString(),
  };
}

const calculateTargetDate = (dateAddedString: string, category: FindingCategoryLevel): string => {
  const dateAdded = new Date(dateAddedString);
  const daysToAdd = FINDING_CATEGORY_TARGET_DAYS[category] || 60; 
  dateAdded.setDate(dateAdded.getDate() + daysToAdd);
  return dateAdded.toISOString();
};


export const OperatorProvider = ({ children }: { children: ReactNode }): JSX.Element => {
  const [operators, setOperators] = useLocalStorage<Operator[]>('operators_rbs_v3', initialOperators.map(enrichOperatorWithRBS)); 

  const getOperatorById = useCallback((id: string) => operators.find(op => op.id === id), [operators]);

  const updateOperatorState = (updatedOperators: Operator[]) => {
    setOperators(updatedOperators.map(op => enrichOperatorWithRBS(op)));
  };

  const addOperator = (
    operatorData: Pick<Operator, 'name' | 'aocNumber'> & Partial<Pick<Operator, 'complexityFactors' | 'complianceData' | 'deviationData' | 'improvementData' | 'legacyRiskFactors' | 'surveillanceFindings'>>
  ): Operator => {
    const newOperatorBase = {
      name: operatorData.name,
      aocNumber: operatorData.aocNumber,
      complexityFactors: operatorData.complexityFactors || { ...DEFAULT_COMPLEXITY_FACTORS },
      complianceData: operatorData.complianceData || { ...DEFAULT_COMPLIANCE_DATA },
      deviationData: operatorData.deviationData || { ...DEFAULT_DEVIATION_DATA },
      improvementData: operatorData.improvementData || { ...DEFAULT_IMPROVEMENT_DATA },
      legacyRiskFactors: operatorData.legacyRiskFactors || { ...DEFAULT_LEGACY_RISK_FACTORS, occurrences: [] }, // Ensure occurrences is initialized
      surveillanceFindings: operatorData.surveillanceFindings || [],
    };
    
    const tempFullOperator: Operator = {
        ...newOperatorBase,
        id: `op-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
        logoUrl: MOCK_OPERATOR_LOGOS[operators.length % MOCK_OPERATOR_LOGOS.length],
        lastUpdated: new Date().toISOString(), 
        exposureScore:0, exposureLevel: ExposureLevel.A, complianceFactorScore:0, deviationFactorScore:0, improvementFactorScore:0, overallPerformanceScore:0, riskIndicatorLevel:1, finalRiskCategoryKey: "1A", suggestedSurveillanceCycleMonths:18, legacyOverallRiskScore:0, legacyOverallRiskLevel: RiskLevel.LOW
    }

    const finalNewOperator = enrichOperatorWithRBS(tempFullOperator);
    setOperators(prevOperators => [...prevOperators, finalNewOperator]); 
    toast.success(`Operator "${finalNewOperator.name}" added successfully!`);
    return finalNewOperator;
  };

  const updateOperatorBasicInfo = (id: string, basicInfo: Pick<Operator, 'name' | 'aocNumber' | 'logoUrl'>) => {
    const currentOperator = getOperatorById(id);
    if (!currentOperator) return;
    const updatedOperator = { ...currentOperator, ...basicInfo, lastUpdated: new Date().toISOString() };
    updateOperatorState(operators.map(op => op.id === id ? updatedOperator : op));
    toast.success(`Operator "${updatedOperator.name}" basic info updated.`);
  };

  const updateOperatorRBSData = (
    id: string, 
    data: {
      complexityFactors?: Partial<ComplexityFactors>;
      complianceData?: Partial<ComplianceData>;
      deviationData?: Partial<DeviationData>;
      improvementData?: Partial<ImprovementData>;
    }
  ) => {
    const currentOperator = getOperatorById(id);
    if (!currentOperator) return;
    
    const updatedOperator = {
      ...currentOperator,
      complexityFactors: data.complexityFactors ? { ...currentOperator.complexityFactors, ...data.complexityFactors } : currentOperator.complexityFactors,
      complianceData: data.complianceData ? { ...currentOperator.complianceData, ...data.complianceData } : currentOperator.complianceData,
      deviationData: data.deviationData ? { ...currentOperator.deviationData, ...data.deviationData } : currentOperator.deviationData,
      improvementData: data.improvementData ? { ...currentOperator.improvementData, ...data.improvementData } : currentOperator.improvementData,
      lastUpdated: new Date().toISOString(),
    };
    updateOperatorState(operators.map(op => op.id === id ? updatedOperator : op));
    toast.success(`RBS data for "${currentOperator.name}" updated.`);
  };


  const deleteOperator = (id: string) => {
    const opName = getOperatorById(id)?.name;
    setOperators(ops => ops.filter(op => op.id !== id));
    toast.success(`Operator "${opName || 'Unknown'}" deleted.`);
  };

  const addLegacyOccurrence = (operatorId: string, occurrenceData: Omit<Occurrence, 'id'>) => {
    const operator = getOperatorById(operatorId);
    if (!operator) return;
    const newOccurrence: Occurrence = {
      ...occurrenceData,
      id: `occ-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
    };
    const updatedLegacyRiskFactors = {
      ...operator.legacyRiskFactors,
      occurrences: [...(operator.legacyRiskFactors?.occurrences || []), newOccurrence],
    };
    const updatedOperator = { ...operator, legacyRiskFactors: updatedLegacyRiskFactors, lastUpdated: new Date().toISOString() };
    updateOperatorState(operators.map(op => op.id === operatorId ? updatedOperator : op));
    toast.success(`Legacy occurrence added to "${operator.name}".`);
  };

  const updateLegacyOccurrence = (operatorId: string, occurrenceId: string, updatedOccurrenceData: Partial<Omit<Occurrence, 'id'>>) => {
    const operator = getOperatorById(operatorId);
    if (!operator) return;
    const updatedOccurrences = (operator.legacyRiskFactors?.occurrences || []).map(occ =>
      occ.id === occurrenceId ? { ...occ, ...updatedOccurrenceData } : occ
    );
    const updatedLegacyRiskFactors = { ...(operator.legacyRiskFactors || DEFAULT_LEGACY_RISK_FACTORS), occurrences: updatedOccurrences };
    const updatedOperator = { ...operator, legacyRiskFactors: updatedLegacyRiskFactors, lastUpdated: new Date().toISOString() };
    updateOperatorState(operators.map(op => op.id === operatorId ? updatedOperator : op));
    toast.success(`Legacy occurrence updated for "${operator.name}".`);
  };

  const deleteLegacyOccurrence = (operatorId: string, occurrenceId: string) => {
    const operator = getOperatorById(operatorId);
    if (!operator) return;

    const currentOccurrences = operator.legacyRiskFactors?.occurrences || [];
    const updatedOccurrences = currentOccurrences.filter(occ => occ.id !== occurrenceId);

    if (updatedOccurrences.length === currentOccurrences.length) {
        console.warn(`Legacy occurrence with ID "${occurrenceId}" not found for operator "${operator.name}". No deletion occurred.`);
        return; 
    }

    const updatedLegacyRiskFactors = { 
      ...(operator.legacyRiskFactors || DEFAULT_LEGACY_RISK_FACTORS), 
      occurrences: updatedOccurrences 
    };
    const finalUpdatedOperator = { 
        ...operator, 
        legacyRiskFactors: updatedLegacyRiskFactors, 
        lastUpdated: new Date().toISOString() 
    };
    
    updateOperatorState(operators.map(op => 
        op.id === operatorId 
        ? finalUpdatedOperator 
        : op
    ));
    toast.success(`Legacy occurrence deleted from "${operator.name}".`);
  };
  
  const addSurveillanceFinding = (operatorId: string, findingData: Omit<SurveillanceFinding, 'id' | 'isCompleted' | 'dateAdded' | 'actualCompletionDate' | 'targetCompletionDate'>) => {
    const operator = getOperatorById(operatorId);
    if (!operator) return;
    const dateAdded = new Date().toISOString();
    const newFinding: SurveillanceFinding = {
      ...findingData,
      id: `sf-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
      isCompleted: false,
      dateAdded: dateAdded,
      targetCompletionDate: calculateTargetDate(dateAdded, findingData.findingCategory),
    };
    const updatedSurveillanceFindings = [...(operator.surveillanceFindings || []), newFinding];
    updateOperatorState(operators.map(op => op.id === operatorId ? {...op, surveillanceFindings: updatedSurveillanceFindings, lastUpdated: new Date().toISOString()} : op));
    toast.success(`Surveillance finding added to "${operator.name}".`);
  };

  const updateSurveillanceFinding = (operatorId: string, findingId: string, updatedData: Partial<Omit<SurveillanceFinding, 'id' | 'dateAdded' | 'actualCompletionDate' | 'targetCompletionDate'>>) => {
    const operator = getOperatorById(operatorId);
    if (!operator) return;
    const currentFindings = operator.surveillanceFindings || [];
    const updatedSurveillanceFindings = currentFindings.map(f => {
      if (f.id === findingId) {
        const newCategory = updatedData.findingCategory || f.findingCategory;
        return { 
          ...f, 
          ...updatedData, 
          targetCompletionDate: calculateTargetDate(f.dateAdded, newCategory),
          actualCompletionDate: updatedData.isCompleted === true && !f.isCompleted ? new Date().toISOString() : updatedData.isCompleted === false ? undefined : f.actualCompletionDate,
          lastUpdated: new Date().toISOString(),
        };
      }
      return f;
    });
    updateOperatorState(operators.map(op => op.id === operatorId ? {...op, surveillanceFindings: updatedSurveillanceFindings} : op));
    toast.success(`Surveillance finding updated for "${operator.name}".`);
  };
  
  const deleteSurveillanceFinding = (operatorId: string, findingId: string) => {
    const operator = getOperatorById(operatorId);
    if (!operator) return;
    
    const currentFindings = operator.surveillanceFindings || [];
    const updatedSurveillanceFindings = currentFindings.filter(f => f.id !== findingId);

    if (updatedSurveillanceFindings.length === currentFindings.length) {
        console.warn(`Surveillance finding with ID "${findingId}" not found for operator "${operator.name}". No deletion occurred.`);
        return; 
    }

    updateOperatorState(operators.map(op => 
      op.id === operatorId 
        ? { ...op, surveillanceFindings: updatedSurveillanceFindings, lastUpdated: new Date().toISOString() } 
        : op
    ));
    toast.success(`Surveillance finding deleted from "${operator.name}".`);
  };

  const toggleSurveillanceFindingCompletion = (operatorId: string, findingId: string) => {
    const operator = getOperatorById(operatorId);
    if (!operator) return;
    const currentFindings = operator.surveillanceFindings || [];
    const updatedSurveillanceFindings = currentFindings.map(f =>
      f.id === findingId ? { ...f, isCompleted: !f.isCompleted, actualCompletionDate: !f.isCompleted ? new Date().toISOString() : undefined } : f
    );
    updateOperatorState(operators.map(op => op.id === operatorId ? {...op, surveillanceFindings: updatedSurveillanceFindings, lastUpdated: new Date().toISOString()} : op));
    const finding = updatedSurveillanceFindings.find(f => f.id === findingId);
    toast.success(`Finding marked as ${finding?.isCompleted ? 'Completed' : 'Open'}.`);
  };


  useEffect(() => {
    const needsProcessing = operators.some(op => 
      !op.hasOwnProperty('overallPerformanceScore') || 
      !op.surveillanceFindings || 
      (op.legacyRiskFactors && !op.legacyRiskFactors.occurrences) || // Check if occurrences is missing
      op.surveillanceFindings.some(sf => !sf.hasOwnProperty('findingCategory'))
    );
    if (needsProcessing) {
      updateOperatorState(operators.map(op => ({
        ...op, 
        surveillanceFindings: (op.surveillanceFindings || []).map(sf => ({
          ...sf,
          findingCategory: sf.findingCategory || FindingCategoryLevel.LEVEL_3 
        })),
        legacyRiskFactors: { // Ensure legacyRiskFactors and occurrences exist
            ...(op.legacyRiskFactors || DEFAULT_LEGACY_RISK_FACTORS),
            occurrences: op.legacyRiskFactors?.occurrences || []
        }
      })));
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []); 

  const contextValue = { 
    operators, 
    getOperatorById, 
    addOperator, 
    updateOperatorBasicInfo,
    updateOperatorRBSData,
    deleteOperator, 
    addLegacyOccurrence, 
    updateLegacyOccurrence, 
    deleteLegacyOccurrence,
    addSurveillanceFinding,
    updateSurveillanceFinding,
    deleteSurveillanceFinding,
    toggleSurveillanceFindingCompletion,
  };

  return React.createElement(
    OperatorContext.Provider,
    { value: contextValue },
    children
  );
};

export const useOperators = (): OperatorContextType => {
  const context = useContext(OperatorContext);
  if (context === undefined) {
    throw new Error('useOperators must be used within an OperatorProvider');
  }
  return context;
};
