import React from 'react';
import { Link } from 'react-router-dom';
import { Operator } from '../types';
import { EyeIcon, TrashIcon, ExclamationTriangleIcon } from './icons';
// RiskBadge can still be used for general display if needed, or create specific ones.
import { useOperators } from '../hooks/useOperators';
import { CHART_HEX_EXPOSURE_LEVEL_COLORS, RBS_PERFORMANCE_TO_INDICATOR_LEVEL } from '../constants';


interface OperatorCardProps {
  operator: Operator;
}

export const OperatorCard: React.FC<OperatorCardProps> = ({ operator }) => {
  const { deleteOperator } = useOperators();

  const handleDelete = (e: React.MouseEvent) => {
    e.preventDefault(); 
    e.stopPropagation();
    if (window.confirm(`Are you sure you want to delete operator "${operator.name}"? This action cannot be undone.`)) {
      deleteOperator(operator.id);
    }
  };
  
  const riskIndicatorInfo = RBS_PERFORMANCE_TO_INDICATOR_LEVEL.find(item => item.level === operator.riskIndicatorLevel);
  const exposureColor = CHART_HEX_EXPOSURE_LEVEL_COLORS[operator.exposureLevel] || '#A0A0A0'; // Default color

  return (
    <div className="bg-white shadow-lg rounded-xl overflow-hidden transition-all hover:shadow-2xl flex flex-col">
      <div className="p-5 flex-grow">
        <div className="flex justify-between items-start mb-2">
          {operator.logoUrl ? (
             <img src={operator.logoUrl} alt={`${operator.name} logo`} className="h-10 object-contain mr-3" />
          ) : (
            <div className="h-10 w-24 bg-slate-200 flex items-center justify-center text-slate-500 text-xs mr-3 rounded">No Logo</div>
          )}
          <div className="text-right">
            <span className="text-xs font-semibold px-2 py-0.5 rounded-full text-white" style={{backgroundColor: exposureColor}}>
                Exp. Lvl: {operator.exposureLevel}
            </span>
            <p className="text-xs text-slate-500 mt-0.5">Score: {operator.exposureScore}</p>
          </div>
        </div>
        <h3 className="text-lg font-semibold text-brand-primary mb-1 truncate" title={operator.name}>{operator.name}</h3>
        <p className="text-xs text-slate-600 mb-2">AOC: {operator.aocNumber}</p>
        
        <div className="border-t border-b border-slate-200 py-2 my-2 space-y-1">
            <div className="flex justify-between items-center text-xs">
                <span className="text-slate-500">Risk Indicator (IDR):</span>
                <span className="font-semibold text-slate-700">{operator.riskIndicatorLevel} ({riskIndicatorInfo?.label || 'N/A'})</span>
            </div>
            <div className="flex justify-between items-center text-xs">
                <span className="text-slate-500">Performance (F(P)):</span>
                <span className="font-semibold text-slate-700">{(operator.overallPerformanceScore * 100).toFixed(1)}%</span>
            </div>
             <div className="flex justify-between items-center text-xs">
                <span className="text-slate-500">Suggested Cycle:</span>
                <span className="font-bold text-brand-secondary">{operator.suggestedSurveillanceCycleMonths} mo.</span>
            </div>
        </div>
        
        <p className="text-xxs text-slate-400 mt-2">Matrix Key: {operator.finalRiskCategoryKey} | Last Updated: {new Date(operator.lastUpdated).toLocaleDateString()}</p>
      </div>
      <div className="bg-slate-50 p-3 flex justify-end space-x-1.5 border-t border-slate-200">
        <Link
          to={`/operator/${operator.id}`}
          className="text-xs bg-brand-secondary text-white hover:bg-sky-700 font-medium py-1.5 px-2.5 rounded-md shadow-sm flex items-center"
          title="View Details"
        >
          <EyeIcon className="h-3.5 w-3.5 mr-1" /> View
        </Link>
        <button
          onClick={handleDelete}
          className="text-xs bg-red-500 text-white hover:bg-red-700 font-medium py-1.5 px-2.5 rounded-md shadow-sm flex items-center"
          title="Delete Operator"
        >
          <TrashIcon className="h-3.5 w-3.5 mr-1" /> Delete
        </button>
      </div>
    </div>
  );
};

// Add text-xxs to tailwind config if not available by default
// tailwind.config = { theme: { extend: { fontSize: { 'xxs': '.65rem' } } } }
// For now, will use text-xs and hope it's small enough.
// The provided index.html does not allow easy modification of tailwind config.
// So, I'll stick to text-xs.
