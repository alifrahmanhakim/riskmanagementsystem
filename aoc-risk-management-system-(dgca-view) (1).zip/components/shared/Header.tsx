
import React, { useEffect } from 'react';
import { Link } from 'react-router-dom';
import { ChartBarIcon, PlaneIcon } from '../icons'; 
import { useAuth } from '../../contexts/AuthContext'; // Import useAuth
import { LoadingSpinner } from './LoadingSpinner';

export const Header: React.FC = () => {
  const { user, isAuthLoading, authError, logout } = useAuth();

  // Effect to ensure Google button is rendered if the div exists.
  // This is a fallback if AuthProvider's initial renderButton call was too early.
  useEffect(() => {
    if (!user && !authError && !isAuthLoading && window.google && window.google.accounts && window.google.accounts.id) {
      const buttonContainer = document.getElementById('googleSignInButtonContainer');
      if (buttonContainer && !buttonContainer.hasChildNodes()) {
         window.google.accounts.id.renderButton(
           buttonContainer,
           { theme: 'outline', size: 'large', type: 'standard', text: 'signin_with' }
         );
      }
    }
  }, [user, authError, isAuthLoading]);

  return (
    <header className="bg-brand-primary shadow-lg">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <Link to="/" className="flex items-center text-white hover:text-brand-secondary transition-colors">
            <PlaneIcon className="h-8 w-8 mr-3" />
            <h1 className="text-xl sm:text-2xl font-bold">AOC Risk Management</h1>
          </Link>
          <nav className="flex space-x-4 items-center">
            <Link
              to="/"
              className="text-slate-300 hover:bg-brand-secondary hover:text-white px-3 py-2 rounded-md text-sm font-medium transition-colors flex items-center"
            >
              <ChartBarIcon className="h-5 w-5 mr-1" />
              Dashboard
            </Link>
            
            {/* Auth Section */}
            <div className="flex items-center">
              {isAuthLoading && <LoadingSpinner size="sm" />}
              {authError && !isAuthLoading && <span className="text-xs text-red-300" title={authError}>Sign-In Error</span>}
              
              {!isAuthLoading && !authError && user && (
                <div className="flex items-center space-x-2">
                  {user.picture && <img src={user.picture} alt="User" className="h-7 w-7 rounded-full" />}
                  <span className="text-slate-300 text-sm hidden sm:inline">{user.name?.split(' ')[0]}</span>
                  <button
                    onClick={logout}
                    className="text-slate-300 hover:bg-red-600 hover:text-white px-2.5 py-1.5 rounded-md text-sm font-medium transition-colors"
                  >
                    Logout
                  </button>
                </div>
              )}
              {!isAuthLoading && !authError && !user && (
                // This container will be filled by Google's script
                <div id="googleSignInButtonContainer" style={{ minHeight: '38px' }}>
                  {/* Google button will render here. Add a fallback text if it fails to render. */}
                  {!document.getElementById('googleSignInButtonContainer')?.hasChildNodes() && process.env.GOOGLE_CLIENT_ID &&
                    <span className="text-xs text-slate-400">Loading Sign-In...</span>
                  }
                   {!process.env.GOOGLE_CLIENT_ID &&
                    <span className="text-xs text-yellow-300">Google Sign-In not configured.</span>
                   }
                </div>
              )}
            </div>
          </nav>
        </div>
      </div>
    </header>
  );
};