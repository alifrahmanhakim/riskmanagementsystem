
import React from 'react';
import { RiskLevel } from '../../types';
import { RISK_LEVEL_COLORS } from '../../constants';

interface RiskBadgeProps {
  level: RiskLevel;
  size?: 'sm' | 'md';
}

export const RiskBadge: React.FC<RiskBadgeProps> = ({ level, size = 'md' }) => {
  const colorClass = RISK_LEVEL_COLORS[level] || 'bg-slate-400';
  const textSizeClass = size === 'sm' ? 'text-xs px-2 py-0.5' : 'text-sm px-3 py-1';

  return (
    <span
      className={`inline-block rounded-full font-semibold text-white ${colorClass} ${textSizeClass}`}
    >
      {level}
    </span>
  );
};
    